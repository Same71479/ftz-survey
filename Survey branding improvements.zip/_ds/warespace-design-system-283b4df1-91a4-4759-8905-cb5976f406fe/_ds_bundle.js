/* @ds-bundle: {"format":3,"namespace":"WareSpaceDesignSystem_283b4d","components":[],"sourceHashes":{"components.js":"8dd632e86971","deck-stage.js":"522102a1c71e","design-canvas.jsx":"d3ddcf4241b9","emails.js":"efe6eaa50dea"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.WareSpaceDesignSystem_283b4d = window.WareSpaceDesignSystem_283b4d || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components.js
try { (() => {
/**
 * WareSpace shared brand components — plain JS renderers.
 * Uses the real WareSpace logo PNGs in assets/logo/.
 */

const WS_LOGO_SRC = {
  // horizontal lockup
  "color": "assets/logo/horizontal-color.png",
  "dark": "assets/logo/horizontal-white.png",
  // for dark bg: white wordmark+icon
  "mono-white": "assets/logo/horizontal-white.png",
  "mono-navy": "assets/logo/horizontal-blue.png",
  "knockout": "assets/logo/horizontal-knockout.png"
};
const WS_ICON_SRC = {
  "color": "assets/logo/marque-color.png",
  "dark": "assets/logo/marque-white.png",
  "mono-white": "assets/logo/marque-white.png",
  "mono-navy": "assets/logo/marque-blue.png",
  "knockout": "assets/logo/marque-knockout.png"
};
const WS_VERTICAL_SRC = {
  "color": "assets/logo/vertical-color.png",
  "dark": "assets/logo/vertical-white.png",
  "mono-white": "assets/logo/vertical-white.png",
  "mono-navy": "assets/logo/vertical-blue.png"
};

// Horizontal logo is 1200×176 → aspect 6.818
// Icon is 358×176 → aspect 2.034
// Vertical is roughly 800×800 square-ish

/* Full horizontal logo lockup (img of the real PNG) */
window.WareSpaceLogo = function (opts = {}) {
  const {
    theme = "color",
    height = 56,
    iconSize,
    wordmarkSize
  } = opts;
  // Back-compat: if iconSize is passed, derive height from it (marque is 176px tall natively)
  const h = iconSize ? iconSize : wordmarkSize ? wordmarkSize * 1.4 : height;
  const src = WS_LOGO_SRC[theme] || WS_LOGO_SRC.color;
  return `<img src="${src}" alt="WareSpace" style="height:${h}px; width:auto; max-width:100%; max-height:100%; object-fit:contain; display:block;" class="ws-logo ws-logo--horizontal" data-theme="${theme}"/>`;
};
window.WareSpaceIcon = function (opts = {}) {
  const {
    theme = "color",
    w = 80,
    h
  } = opts;
  const src = WS_ICON_SRC[theme] || WS_ICON_SRC.color;
  // Icon native aspect ratio 358/176 ≈ 2.034
  const height = h || Math.round(w * (176 / 358));
  return `<img src="${src}" alt="WareSpace" style="width:${w}px; height:${height}px; max-width:100%; object-fit:contain; display:block;" class="ws-logo__icon" data-theme="${theme}"/>`;
};
window.WareSpaceLogoVertical = function (opts = {}) {
  const {
    theme = "color",
    height = 200
  } = opts;
  const src = WS_VERTICAL_SRC[theme] || WS_VERTICAL_SRC.color;
  return `<img src="${src}" alt="WareSpace" style="height:${height}px; width:auto; max-width:100%; max-height:100%; object-fit:contain; display:block;" class="ws-logo ws-logo--vertical" data-theme="${theme}"/>`;
};

/* Stripe tape accent (unchanged) */
window.WareSpaceStripe = function (opts = {}) {
  const {
    w = 300,
    h = 46,
    color = "#3DBE7A"
  } = opts;
  return `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 46" width="${w}" height="${h}"
       preserveAspectRatio="none" style="transform:rotate(-1.3deg)">
    <path d="M 4 26 C 40 14, 90 18, 140 20 S 240 30, 294 18 L 296 38 C 250 50, 180 44, 120 42 S 30 46, 6 42 Z" fill="${color}"/>
  </svg>`;
};
window.WareSpaceCopy = async function (value, label) {
  try {
    await navigator.clipboard.writeText(value);
    window.WareSpaceToast(`Copied ${label || value}`);
  } catch (e) {
    window.WareSpaceToast("Copy failed — select & ⌘C");
  }
};
window.WareSpaceToast = function (msg) {
  let t = document.getElementById("__ws_toast");
  if (!t) {
    t = document.createElement("div");
    t.id = "__ws_toast";
    t.style.cssText = `
      position:fixed; bottom:40px; left:50%; transform:translateX(-50%) translateY(20px);
      background:#102442; color:#fff; padding:12px 20px; border-radius:999px;
      font-family:Roboto,system-ui,sans-serif; font-size:14px; font-weight:500;
      letter-spacing:0.01em; z-index:99999; opacity:0;
      transition:opacity .2s ease, transform .25s cubic-bezier(.2,.9,.3,1);
      box-shadow:0 10px 32px rgba(16,36,66,.25);
      pointer-events:none;`;
    document.body.appendChild(t);
  }
  t.textContent = msg;
  requestAnimationFrame(() => {
    t.style.opacity = "1";
    t.style.transform = "translateX(-50%) translateY(0)";
  });
  clearTimeout(t.__timer);
  t.__timer = setTimeout(() => {
    t.style.opacity = "0";
    t.style.transform = "translateX(-50%) translateY(20px)";
  }, 1500);
};

/* Download helper — now points at real PNGs via fetch-and-save */
window.WareSpaceDownload = async function (filename, label, srcPath) {
  if (srcPath) {
    // Real asset download
    try {
      const res = await fetch(srcPath);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      window.WareSpaceToast(`Downloaded ${label || filename}`);
      return;
    } catch (e) {
      // fall through to placeholder
    }
  }
  const content = `WareSpace Brand Asset\n\nPlaceholder: ${filename}\n`;
  const blob = new Blob([content], {
    type: "text/plain"
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  window.WareSpaceToast(`Downloaded ${label || filename}`);
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "components.js", error: String((e && e.message) || e) }); }

// deck-stage.js
try { (() => {
/**
 * <deck-stage> — reusable web component for HTML decks.
 *
 * Handles:
 *  (a) speaker notes — reads <script type="application/json" id="speaker-notes">
 *      and posts {slideIndexChanged: N} to the parent window on nav.
 *  (b) keyboard navigation — ←/→, PgUp/PgDn, Space, Home/End, number keys.
 *  (c) press R to reset to slide 0 (with a tasteful keyboard hint).
 *  (d) bottom-center overlay showing slide count + hints, fades out on idle.
 *  (e) auto-scaling — inner canvas is a fixed design size (default 1920×1080)
 *      scaled with `transform: scale()` to fit the viewport, letterboxed.
 *      Set the `noscale` attribute to render at authored size (1:1) — the
 *      PPTX exporter sets this so its DOM capture sees unscaled geometry.
 *  (f) print — `@media print` lays every slide out as its own page at the
 *      design size, so the browser's Print → Save as PDF produces a clean
 *      one-page-per-slide PDF with no extra setup.
 *
 * Slides are HIDDEN, not unmounted. Non-active slides stay in the DOM with
 * `visibility: hidden` + `opacity: 0`, so their state (videos, iframes,
 * form inputs, React trees) is preserved across navigation.
 *
 * Lifecycle event — the component dispatches a `slidechange` CustomEvent on
 * itself whenever the active slide changes (including the initial mount).
 * The event bubbles and composes out of shadow DOM, so you can listen on
 * the <deck-stage> element or on document:
 *
 *   document.querySelector('deck-stage').addEventListener('slidechange', (e) => {
 *     e.detail.index         // new 0-based index
 *     e.detail.previousIndex // previous index, or -1 on init
 *     e.detail.total         // total slide count
 *     e.detail.slide         // the new active slide element
 *     e.detail.previousSlide // the prior slide element, or null on init
 *     e.detail.reason        // 'init' | 'keyboard' | 'click' | 'tap' | 'api'
 *   });
 *
 * Persistence: current slide index is saved to localStorage keyed by the
 * document path, so refresh returns you to the same place.
 *
 * Usage:
 *   <deck-stage width="1920" height="1080">
 *     <section data-label="Title">...</section>
 *     <section data-label="Agenda">...</section>
 *   </deck-stage>
 *
 * Slides are the direct element children of <deck-stage>. Each slide is
 * automatically tagged with:
 *   - data-screen-label="NN Label"   (1-indexed, for comment flow)
 *   - data-om-validate="no_overflowing_text,no_overlapping_text,slide_sized_text"
 */

(() => {
  const DESIGN_W_DEFAULT = 1920;
  const DESIGN_H_DEFAULT = 1080;
  const STORAGE_PREFIX = 'deck-stage:slide:';
  const OVERLAY_HIDE_MS = 1800;
  const VALIDATE_ATTR = 'no_overflowing_text,no_overlapping_text,slide_sized_text';
  const pad2 = n => String(n).padStart(2, '0');
  const stylesheet = `
    :host {
      position: fixed;
      inset: 0;
      display: block;
      background: #000;
      color: #fff;
      font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", Helvetica, Arial, sans-serif;
      overflow: hidden;
    }

    .stage {
      position: absolute;
      inset: 0;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .canvas {
      position: relative;
      transform-origin: center center;
      flex-shrink: 0;
      background: #fff;
      will-change: transform;
    }

    /* Slides live in light DOM (via <slot>) so authored CSS still applies.
       We absolutely position each slotted child to stack them. */
    ::slotted(*) {
      position: absolute !important;
      inset: 0 !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden;
      opacity: 0;
      pointer-events: none;
      visibility: hidden;
    }
    ::slotted([data-deck-active]) {
      opacity: 1;
      pointer-events: auto;
      visibility: visible;
    }

    /* Tap zones for mobile — back/forward thirds like Stories.
       Transparent, no visible UI, don't block the overlay. */
    .tapzones {
      position: fixed;
      inset: 0;
      display: flex;
      z-index: 2147482000;
      pointer-events: none;
    }
    .tapzone {
      flex: 1;
      pointer-events: auto;
      -webkit-tap-highlight-color: transparent;
    }
    /* Only activate tap zones on coarse pointers (touch devices). */
    @media (hover: hover) and (pointer: fine) {
      .tapzones { display: none; }
    }

    .overlay {
      position: fixed;
      left: 50%;
      bottom: 22px;
      transform: translate(-50%, 6px) scale(0.92);
      filter: blur(6px);
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 4px;
      background: #000;
      color: #fff;
      border-radius: 999px;
      font-size: 12px;
      font-feature-settings: "tnum" 1;
      letter-spacing: 0.01em;
      opacity: 0;
      pointer-events: none;
      transition: opacity 260ms ease, transform 260ms cubic-bezier(.2,.8,.2,1), filter 260ms ease;
      transform-origin: center bottom;
      z-index: 2147483000;
      user-select: none;
    }
    .overlay[data-visible] {
      opacity: 1;
      pointer-events: auto;
      transform: translate(-50%, 0) scale(1);
      filter: blur(0);
    }

    .btn {
      appearance: none;
      -webkit-appearance: none;
      background: transparent;
      border: 0;
      margin: 0;
      padding: 0;
      color: inherit;
      font: inherit;
      cursor: default;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      height: 28px;
      min-width: 28px;
      border-radius: 999px;
      color: rgba(255,255,255,0.72);
      transition: background 140ms ease, color 140ms ease;
      -webkit-tap-highlight-color: transparent;
    }
    .btn:hover { background: rgba(255,255,255,0.12); color: #fff; }
    .btn:active { background: rgba(255,255,255,0.18); }
    .btn:focus { outline: none; }
    .btn:focus-visible { outline: none; }
    .btn::-moz-focus-inner { border: 0; }
    .btn svg { width: 14px; height: 14px; display: block; }
    .btn.reset {
      font-size: 11px;
      font-weight: 500;
      letter-spacing: 0.02em;
      padding: 0 10px 0 12px;
      gap: 6px;
      color: rgba(255,255,255,0.72);
    }
    .btn.reset .kbd {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 16px;
      height: 16px;
      padding: 0 4px;
      font-family: ui-monospace, "SF Mono", Menlo, Consolas, monospace;
      font-size: 10px;
      line-height: 1;
      color: rgba(255,255,255,0.88);
      background: rgba(255,255,255,0.12);
      border-radius: 4px;
    }

    .count {
      font-variant-numeric: tabular-nums;
      color: #fff;
      font-weight: 500;
      padding: 0 8px;
      min-width: 42px;
      text-align: center;
      font-size: 12px;
    }
    .count .sep { color: rgba(255,255,255,0.45); margin: 0 3px; font-weight: 400; }
    .count .total { color: rgba(255,255,255,0.55); }

    .divider {
      width: 1px;
      height: 14px;
      background: rgba(255,255,255,0.18);
      margin: 0 2px;
    }

    /* ── Print: one page per slide, no chrome ────────────────────────────
       The screen layout stacks every slide at inset:0 inside a scaled
       canvas; for print we want them in document flow at the authored
       design size so the browser paginates one slide per sheet. The
       @page size is set from the width/height attributes via the inline
       <style id="deck-stage-print-page"> that connectedCallback injects
       into <head> (the @page at-rule has no effect inside shadow DOM). */
    @media print {
      :host {
        position: static;
        inset: auto;
        background: none;
        overflow: visible;
        color: inherit;
      }
      .stage { position: static; display: block; }
      .canvas {
        transform: none !important;
        width: auto !important;
        height: auto !important;
        background: none;
        will-change: auto;
      }
      ::slotted(*) {
        position: relative !important;
        inset: auto !important;
        width: var(--deck-design-w) !important;
        height: var(--deck-design-h) !important;
        box-sizing: border-box !important;
        opacity: 1 !important;
        visibility: visible !important;
        pointer-events: auto;
        break-after: page;
        page-break-after: always;
        break-inside: avoid;
        overflow: hidden;
      }
      ::slotted(*:last-child) {
        break-after: auto;
        page-break-after: auto;
      }
      .overlay, .tapzones { display: none !important; }
    }
  `;
  class DeckStage extends HTMLElement {
    static get observedAttributes() {
      return ['width', 'height', 'noscale'];
    }
    constructor() {
      super();
      this._root = this.attachShadow({
        mode: 'open'
      });
      this._index = 0;
      this._slides = [];
      this._notes = [];
      this._hideTimer = null;
      this._mouseIdleTimer = null;
      this._storageKey = STORAGE_PREFIX + (location.pathname || '/');
      this._onKey = this._onKey.bind(this);
      this._onResize = this._onResize.bind(this);
      this._onSlotChange = this._onSlotChange.bind(this);
      this._onMouseMove = this._onMouseMove.bind(this);
      this._onTapBack = this._onTapBack.bind(this);
      this._onTapForward = this._onTapForward.bind(this);
    }
    get designWidth() {
      return parseInt(this.getAttribute('width'), 10) || DESIGN_W_DEFAULT;
    }
    get designHeight() {
      return parseInt(this.getAttribute('height'), 10) || DESIGN_H_DEFAULT;
    }
    connectedCallback() {
      this._render();
      this._loadNotes();
      this._syncPrintPageRule();
      window.addEventListener('keydown', this._onKey);
      window.addEventListener('resize', this._onResize);
      window.addEventListener('mousemove', this._onMouseMove, {
        passive: true
      });
      // Initial collection + layout happens via slotchange, which fires on mount.
    }
    disconnectedCallback() {
      window.removeEventListener('keydown', this._onKey);
      window.removeEventListener('resize', this._onResize);
      window.removeEventListener('mousemove', this._onMouseMove);
      if (this._hideTimer) clearTimeout(this._hideTimer);
      if (this._mouseIdleTimer) clearTimeout(this._mouseIdleTimer);
    }
    attributeChangedCallback() {
      if (this._canvas) {
        this._canvas.style.width = this.designWidth + 'px';
        this._canvas.style.height = this.designHeight + 'px';
        this._canvas.style.setProperty('--deck-design-w', this.designWidth + 'px');
        this._canvas.style.setProperty('--deck-design-h', this.designHeight + 'px');
        this._fit();
        this._syncPrintPageRule();
      }
    }
    _render() {
      const style = document.createElement('style');
      style.textContent = stylesheet;
      const stage = document.createElement('div');
      stage.className = 'stage';
      const canvas = document.createElement('div');
      canvas.className = 'canvas';
      canvas.style.width = this.designWidth + 'px';
      canvas.style.height = this.designHeight + 'px';
      canvas.style.setProperty('--deck-design-w', this.designWidth + 'px');
      canvas.style.setProperty('--deck-design-h', this.designHeight + 'px');
      const slot = document.createElement('slot');
      slot.addEventListener('slotchange', this._onSlotChange);
      canvas.appendChild(slot);
      stage.appendChild(canvas);

      // Tap zones (mobile): left third = back, right third = forward.
      const tapzones = document.createElement('div');
      tapzones.className = 'tapzones export-hidden';
      tapzones.setAttribute('aria-hidden', 'true');
      const tzBack = document.createElement('div');
      tzBack.className = 'tapzone tapzone--back';
      const tzMid = document.createElement('div');
      tzMid.className = 'tapzone tapzone--mid';
      tzMid.style.pointerEvents = 'none';
      const tzFwd = document.createElement('div');
      tzFwd.className = 'tapzone tapzone--fwd';
      tzBack.addEventListener('click', this._onTapBack);
      tzFwd.addEventListener('click', this._onTapForward);
      tapzones.append(tzBack, tzMid, tzFwd);

      // Overlay: compact, solid black, with clickable controls.
      const overlay = document.createElement('div');
      overlay.className = 'overlay export-hidden';
      overlay.setAttribute('role', 'toolbar');
      overlay.setAttribute('aria-label', 'Deck controls');
      overlay.innerHTML = `
        <button class="btn prev" type="button" aria-label="Previous slide" title="Previous (←)">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 3L5 8l5 5"/></svg>
        </button>
        <span class="count" aria-live="polite"><span class="current">1</span><span class="sep">/</span><span class="total">1</span></span>
        <button class="btn next" type="button" aria-label="Next slide" title="Next (→)">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 3l5 5-5 5"/></svg>
        </button>
        <span class="divider"></span>
        <button class="btn reset" type="button" aria-label="Reset to first slide" title="Reset (R)">Reset<span class="kbd">R</span></button>
      `;
      overlay.querySelector('.prev').addEventListener('click', () => this._go(this._index - 1, 'click'));
      overlay.querySelector('.next').addEventListener('click', () => this._go(this._index + 1, 'click'));
      overlay.querySelector('.reset').addEventListener('click', () => this._go(0, 'click'));
      this._root.append(style, stage, tapzones, overlay);
      this._canvas = canvas;
      this._slot = slot;
      this._overlay = overlay;
      this._countEl = overlay.querySelector('.current');
      this._totalEl = overlay.querySelector('.total');
    }

    /** @page must live in the document stylesheet — it's a no-op inside
     *  shadow DOM. Inject/update a single <head> style tag so the print
     *  sheet matches the design size and Save-as-PDF yields one slide per
     *  page with no margins. */
    _syncPrintPageRule() {
      const id = 'deck-stage-print-page';
      let tag = document.getElementById(id);
      if (!tag) {
        tag = document.createElement('style');
        tag.id = id;
        document.head.appendChild(tag);
      }
      tag.textContent = '@page { size: ' + this.designWidth + 'px ' + this.designHeight + 'px; margin: 0; } ' + '@media print { html, body { margin: 0 !important; padding: 0 !important; background: none !important; overflow: visible !important; height: auto !important; } ' + '* { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }';
    }
    _onSlotChange() {
      this._collectSlides();
      this._restoreIndex();
      this._applyIndex({
        showOverlay: false,
        broadcast: true,
        reason: 'init'
      });
      this._fit();
    }
    _collectSlides() {
      const assigned = this._slot.assignedElements({
        flatten: true
      });
      this._slides = assigned.filter(el => {
        // Skip template/style/script nodes even if someone slots them.
        const tag = el.tagName;
        return tag !== 'TEMPLATE' && tag !== 'SCRIPT' && tag !== 'STYLE';
      });
      this._slides.forEach((slide, i) => {
        const n = i + 1;
        // Determine a label for comment flow: prefer explicit data-label,
        // then an existing data-screen-label, then first heading, else "Slide".
        let label = slide.getAttribute('data-label');
        if (!label) {
          const existing = slide.getAttribute('data-screen-label');
          if (existing) {
            // Strip any leading number the author may have included.
            label = existing.replace(/^\s*\d+\s*/, '').trim() || existing;
          }
        }
        if (!label) {
          const h = slide.querySelector('h1, h2, h3, [data-title]');
          if (h) label = (h.textContent || '').trim().slice(0, 40);
        }
        if (!label) label = 'Slide';
        slide.setAttribute('data-screen-label', `${pad2(n)} ${label}`);

        // Validation attribute for comment flow / auto-checks.
        if (!slide.hasAttribute('data-om-validate')) {
          slide.setAttribute('data-om-validate', VALIDATE_ATTR);
        }
        slide.setAttribute('data-deck-slide', String(i));
      });
      if (this._totalEl) this._totalEl.textContent = String(this._slides.length || 1);
      if (this._index >= this._slides.length) this._index = Math.max(0, this._slides.length - 1);
    }
    _loadNotes() {
      const tag = document.getElementById('speaker-notes');
      if (!tag) {
        this._notes = [];
        return;
      }
      try {
        const parsed = JSON.parse(tag.textContent || '[]');
        if (Array.isArray(parsed)) this._notes = parsed;
      } catch (e) {
        console.warn('[deck-stage] Failed to parse #speaker-notes JSON:', e);
        this._notes = [];
      }
    }
    _restoreIndex() {
      try {
        const raw = localStorage.getItem(this._storageKey);
        if (raw != null) {
          const n = parseInt(raw, 10);
          if (Number.isFinite(n) && n >= 0 && n < this._slides.length) {
            this._index = n;
          }
        }
      } catch (e) {/* ignore */}
    }
    _persistIndex() {
      try {
        localStorage.setItem(this._storageKey, String(this._index));
      } catch (e) {/* ignore */}
    }
    _applyIndex({
      showOverlay = true,
      broadcast = true,
      reason = 'init'
    } = {}) {
      if (!this._slides.length) return;
      const prev = this._prevIndex == null ? -1 : this._prevIndex;
      const curr = this._index;
      this._slides.forEach((s, i) => {
        if (i === curr) s.setAttribute('data-deck-active', '');else s.removeAttribute('data-deck-active');
      });
      if (this._countEl) this._countEl.textContent = String(curr + 1);
      this._persistIndex();
      if (broadcast) {
        // (1) Legacy: host-window postMessage for speaker-notes renderers.
        try {
          window.postMessage({
            slideIndexChanged: curr
          }, '*');
        } catch (e) {}

        // (2) In-page CustomEvent on the <deck-stage> element itself.
        //     Bubbles and composes out of shadow DOM so slide code can listen:
        //       document.querySelector('deck-stage').addEventListener('slidechange', e => {
        //         e.detail.index, e.detail.previousIndex, e.detail.total, e.detail.slide, e.detail.reason
        //       });
        const detail = {
          index: curr,
          previousIndex: prev,
          total: this._slides.length,
          slide: this._slides[curr] || null,
          previousSlide: prev >= 0 ? this._slides[prev] || null : null,
          reason: reason // 'init' | 'keyboard' | 'click' | 'tap' | 'api'
        };
        this.dispatchEvent(new CustomEvent('slidechange', {
          detail,
          bubbles: true,
          composed: true
        }));
      }
      this._prevIndex = curr;
      if (showOverlay) this._flashOverlay();
    }
    _flashOverlay() {
      if (!this._overlay) return;
      this._overlay.setAttribute('data-visible', '');
      if (this._hideTimer) clearTimeout(this._hideTimer);
      this._hideTimer = setTimeout(() => {
        this._overlay.removeAttribute('data-visible');
      }, OVERLAY_HIDE_MS);
    }
    _fit() {
      if (!this._canvas) return;
      // PPTX export sets noscale so the DOM capture sees authored-size
      // geometry — the scaled canvas is in shadow DOM, so the exporter's
      // resetTransformSelector can't reach .canvas.style.transform directly.
      if (this.hasAttribute('noscale')) {
        this._canvas.style.transform = 'none';
        return;
      }
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const s = Math.min(vw / this.designWidth, vh / this.designHeight);
      this._canvas.style.transform = `scale(${s})`;
    }
    _onResize() {
      this._fit();
    }
    _onMouseMove() {
      // Keep overlay visible while mouse moves; hide after idle.
      this._flashOverlay();
    }
    _onTapBack(e) {
      e.preventDefault();
      this._go(this._index - 1, 'tap');
    }
    _onTapForward(e) {
      e.preventDefault();
      this._go(this._index + 1, 'tap');
    }
    _onKey(e) {
      // Ignore when the user is typing.
      const t = e.target;
      if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const key = e.key;
      let handled = true;
      if (key === 'ArrowRight' || key === 'PageDown' || key === ' ' || key === 'Spacebar') {
        this._go(this._index + 1, 'keyboard');
      } else if (key === 'ArrowLeft' || key === 'PageUp') {
        this._go(this._index - 1, 'keyboard');
      } else if (key === 'Home') {
        this._go(0, 'keyboard');
      } else if (key === 'End') {
        this._go(this._slides.length - 1, 'keyboard');
      } else if (key === 'r' || key === 'R') {
        this._go(0, 'keyboard');
      } else if (/^[0-9]$/.test(key)) {
        // 1..9 jump to that slide; 0 jumps to 10.
        const n = key === '0' ? 9 : parseInt(key, 10) - 1;
        if (n < this._slides.length) this._go(n, 'keyboard');
      } else {
        handled = false;
      }
      if (handled) {
        e.preventDefault();
        this._flashOverlay();
      }
    }
    _go(i, reason = 'api') {
      if (!this._slides.length) return;
      const clamped = Math.max(0, Math.min(this._slides.length - 1, i));
      if (clamped === this._index) {
        this._flashOverlay();
        return;
      }
      this._index = clamped;
      this._applyIndex({
        showOverlay: true,
        broadcast: true,
        reason
      });
    }

    // Public API ------------------------------------------------------------

    /** Current slide index (0-based). */
    get index() {
      return this._index;
    }
    /** Total slide count. */
    get length() {
      return this._slides.length;
    }
    /** Programmatically navigate. */
    goTo(i) {
      this._go(i, 'api');
    }
    next() {
      this._go(this._index + 1, 'api');
    }
    prev() {
      this._go(this._index - 1, 'api');
    }
    reset() {
      this._go(0, 'api');
    }
  }
  if (!customElements.get('deck-stage')) {
    customElements.define('deck-stage', DeckStage);
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "deck-stage.js", error: String((e && e.message) || e) }); }

// design-canvas.jsx
try { (() => {
/* BEGIN USAGE */
// DesignCanvas.jsx — Figma-ish design canvas wrapper
// Warm gray grid bg + Sections + Artboards + PostIt notes.
// Exports (to window): DesignCanvas, DCSection, DCArtboard, DCPostIt.
// Artboards are reorderable (grip-drag), deletable, labels/titles are
// inline-editable, and any artboard can be opened in a fullscreen focus
// overlay (←/→/Esc). State persists to a .design-canvas.state.json sidecar
// via the host bridge. No assets, no deps.
//
// Usage:
//   <DesignCanvas>
//     <DCSection id="onboarding" title="Onboarding" subtitle="First-run variants">
//       <DCArtboard id="a" label="A · Dusk" width={260} height={480}>…</DCArtboard>
//       <DCArtboard id="b" label="B · Minimal" width={260} height={480}>…</DCArtboard>
//     </DCSection>
//   </DesignCanvas>
//
// Artboards are static design frames, not scroll regions — never use
// height: 100% + overflow: auto/scroll on inner elements; size each artboard
// to fit its content (explicit pixel height, or let it grow).
/* END USAGE */

const DC = {
  bg: '#f0eee9',
  grid: 'rgba(0,0,0,0.06)',
  label: 'rgba(60,50,40,0.7)',
  title: 'rgba(40,30,20,0.85)',
  subtitle: 'rgba(60,50,40,0.6)',
  postitBg: '#fef4a8',
  postitText: '#5a4a2a',
  font: '-apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif'
};

// One-time CSS injection (classes are dc-prefixed so they don't collide with
// the hosted design's own styles).
if (typeof document !== 'undefined' && !document.getElementById('dc-styles')) {
  const s = document.createElement('style');
  s.id = 'dc-styles';
  s.textContent = ['.dc-editable{cursor:text;outline:none;white-space:nowrap;border-radius:3px;padding:0 2px;margin:0 -2px}', '.dc-editable:focus{background:#fff;box-shadow:0 0 0 1.5px #c96442}', '[data-dc-slot]{transition:transform .18s cubic-bezier(.2,.7,.3,1)}', '[data-dc-slot].dc-dragging{transition:none;z-index:10;pointer-events:none}', '[data-dc-slot].dc-dragging .dc-card{box-shadow:0 12px 40px rgba(0,0,0,.25),0 0 0 2px #c96442;transform:scale(1.02)}',
  // isolation:isolate contains artboard content's z-indexes so a
  // z-indexed child (sticky navbar etc.) can't paint over .dc-header or
  // the .dc-menu popover that drops into the top of the card.
  '.dc-card{isolation:isolate;transition:box-shadow .15s,transform .15s}', '.dc-card *{scrollbar-width:none}', '.dc-card *::-webkit-scrollbar{display:none}',
  // Per-artboard header: grip + label on the left, delete/expand on the
  // right. Single flex row; when the artboard's on-screen width is too
  // narrow for both the label yields (ellipsis, then hidden entirely below
  // ~4ch via the container query) and the buttons stay on the row.
  '.dc-header{position:absolute;bottom:100%;left:-4px;margin-bottom:calc(4px * var(--dc-inv-zoom,1));z-index:2;', '  display:flex;align-items:center;container-type:inline-size}', '.dc-labelrow{display:flex;align-items:center;gap:4px;height:24px;flex:1 1 auto;min-width:0}', '.dc-grip{flex:0 0 auto;cursor:grab;display:flex;align-items:center;padding:5px 4px;border-radius:4px;transition:background .12s,opacity .12s}', '.dc-grip:hover{background:rgba(0,0,0,.08)}', '.dc-grip:active{cursor:grabbing}', '.dc-labeltext{flex:1 1 auto;min-width:0;cursor:pointer;border-radius:4px;padding:3px 6px;', '  display:flex;align-items:center;transition:background .12s;overflow:hidden}',
  // Below ~4ch of label room: hide the label entirely, and drop the grip to
  // hover-only (same reveal rule as .dc-btns) so a narrow header is clean
  // until the card is moused.
  '@container (max-width: 110px){', '  .dc-labeltext{display:none}', '  .dc-grip{opacity:0}', '  [data-dc-slot]:hover .dc-grip{opacity:1}', '}', '.dc-labeltext:hover{background:rgba(0,0,0,.05)}', '.dc-labeltext .dc-editable{overflow:hidden;text-overflow:ellipsis;max-width:100%}', '.dc-labeltext .dc-editable:focus{overflow:visible;text-overflow:clip}', '.dc-btns{flex:0 0 auto;margin-left:auto;display:flex;gap:2px;opacity:0;transition:opacity .12s}', '[data-dc-slot]:hover .dc-btns,.dc-btns:has(.dc-menu){opacity:1}', '.dc-expand,.dc-kebab{width:22px;height:22px;border-radius:5px;border:none;cursor:pointer;padding:0;', '  background:transparent;color:rgba(60,50,40,.7);display:flex;align-items:center;justify-content:center;', '  font:inherit;transition:background .12s,color .12s}', '.dc-expand:hover,.dc-kebab:hover{background:rgba(0,0,0,.06);color:#2a251f}',
  // Slot hosting an open menu floats above later siblings (which otherwise
  // paint on top — same z-index:auto, later DOM order) so the popup isn't
  // clipped by the next card.
  '[data-dc-slot]:has(.dc-menu){z-index:10}', '.dc-menu{position:absolute;top:100%;right:0;margin-top:4px;background:#fff;border-radius:8px;', '  box-shadow:0 8px 28px rgba(0,0,0,.18),0 0 0 1px rgba(0,0,0,.05);padding:4px;min-width:160px;z-index:10}', '.dc-menu button{display:block;width:100%;padding:7px 10px;border:0;background:transparent;', '  border-radius:5px;font-family:inherit;font-size:13px;font-weight:500;line-height:1.2;', '  color:#29261b;cursor:pointer;text-align:left;transition:background .12s;white-space:nowrap}', '.dc-menu button:hover{background:rgba(0,0,0,.05)}', '.dc-menu hr{border:0;border-top:1px solid rgba(0,0,0,.08);margin:4px 2px}', '.dc-menu .dc-danger{color:#c96442}', '.dc-menu .dc-danger:hover{background:rgba(201,100,66,.1)}',
  // Chrome (titles / labels / buttons) counter-scales against the viewport
  // zoom so it stays a constant on-screen size. --dc-inv-zoom is set by
  // DCViewport on every transform update and inherits to all descendants —
  // any overlay inside the world (e.g. a TweaksPanel on an artboard) can use
  // it the same way.
  //
  // The header uses transform:scale (out-of-flow, so layout impact doesn't
  // matter) with its world-space width set to card-width / inv-zoom so that
  // after counter-scaling its on-screen width exactly matches the card's —
  // that's what lets the container query + text-overflow behave against the
  // card's visible edge at every zoom level.
  //
  // The section head uses CSS zoom instead of transform so its layout box
  // grows with the counter-scale, pushing the card row down — otherwise the
  // constant-screen-size title would overflow into the (shrinking) world-
  // space gap and overlap the artboard headers at low zoom.
  '.dc-header{width:calc((100% + 4px) / var(--dc-inv-zoom,1));', '  transform:scale(var(--dc-inv-zoom,1));transform-origin:bottom left}', '.dc-sectionhead{zoom:var(--dc-inv-zoom,1)}'].join('\n');
  document.head.appendChild(s);
}
const DCCtx = React.createContext(null);

// Recursively unwrap React.Fragment so <>…</> grouping doesn't hide
// DCSection/DCArtboard children from the type-based walks below.
function dcFlatten(children) {
  const out = [];
  React.Children.forEach(children, c => {
    if (c && c.type === React.Fragment) out.push(...dcFlatten(c.props.children));else out.push(c);
  });
  return out;
}

// ─────────────────────────────────────────────────────────────
// DesignCanvas — stateful wrapper around the pan/zoom viewport.
// Owns runtime state (per-section order, renamed titles/labels, hidden
// artboards, focused artboard). Order/titles/labels/hidden persist to a
// .design-canvas.state.json
// sidecar next to the HTML. Reads go via plain fetch() so the saved
// arrangement is visible anywhere the HTML + sidecar are served together
// (omelette preview, direct link, downloaded zip). Writes go through the
// host's window.omelette bridge — editing requires the omelette runtime.
// Focus is ephemeral.
// ─────────────────────────────────────────────────────────────
const DC_STATE_FILE = '.design-canvas.state.json';
function DesignCanvas({
  children,
  minScale,
  maxScale,
  style
}) {
  const [state, setState] = React.useState({
    sections: {},
    focus: null
  });
  // Hold rendering until the sidecar read settles so the saved order/titles
  // appear on first paint (no source-order flash). didRead gates writes until
  // the read settles so the empty initial state can't clobber a slow read;
  // skipNextWrite suppresses the one echo-write that would otherwise follow
  // hydration.
  const [ready, setReady] = React.useState(false);
  const didRead = React.useRef(false);
  const skipNextWrite = React.useRef(false);
  React.useEffect(() => {
    let off = false;
    fetch('./' + DC_STATE_FILE).then(r => r.ok ? r.json() : null).then(saved => {
      if (off || !saved || !saved.sections) return;
      skipNextWrite.current = true;
      setState(s => ({
        ...s,
        sections: saved.sections
      }));
    }).catch(() => {}).finally(() => {
      didRead.current = true;
      if (!off) setReady(true);
    });
    const t = setTimeout(() => {
      if (!off) setReady(true);
    }, 150);
    return () => {
      off = true;
      clearTimeout(t);
    };
  }, []);
  React.useEffect(() => {
    if (!didRead.current) return;
    if (skipNextWrite.current) {
      skipNextWrite.current = false;
      return;
    }
    const t = setTimeout(() => {
      window.omelette?.writeFile(DC_STATE_FILE, JSON.stringify({
        sections: state.sections
      })).catch(() => {});
    }, 250);
    return () => clearTimeout(t);
  }, [state.sections]);

  // Build registries synchronously from children so FocusOverlay can read
  // them in the same render. Fragments are flattened; wrapping in other
  // elements still opts out of focus/reorder.
  const registry = {}; // slotId -> { sectionId, artboard }
  const sectionMeta = {}; // sectionId -> { title, subtitle, slotIds[] }
  const sectionOrder = [];
  dcFlatten(children).forEach(sec => {
    if (!sec || sec.type !== DCSection) return;
    const sid = sec.props.id ?? sec.props.title;
    if (!sid) return;
    sectionOrder.push(sid);
    const persisted = state.sections[sid] || {};
    const abs = [];
    dcFlatten(sec.props.children).forEach(ab => {
      if (!ab || ab.type !== DCArtboard) return;
      const aid = ab.props.id ?? ab.props.label;
      if (aid) abs.push([aid, ab]);
    });
    // hidden is scoped to one source revision — when the agent regenerates
    // (artboard-ID set changes), prior deletes don't apply to new content.
    const srcKey = abs.map(([k]) => k).join('\x1f');
    const hidden = persisted.srcKey === srcKey ? persisted.hidden || [] : [];
    const srcIds = [];
    abs.forEach(([aid, ab]) => {
      if (hidden.includes(aid)) return;
      registry[`${sid}/${aid}`] = {
        sectionId: sid,
        artboard: ab
      };
      srcIds.push(aid);
    });
    const kept = (persisted.order || []).filter(k => srcIds.includes(k));
    sectionMeta[sid] = {
      title: persisted.title ?? sec.props.title,
      subtitle: sec.props.subtitle,
      slotIds: [...kept, ...srcIds.filter(k => !kept.includes(k))]
    };
  });
  const api = React.useMemo(() => ({
    state,
    section: id => state.sections[id] || {},
    patchSection: (id, p) => setState(s => ({
      ...s,
      sections: {
        ...s.sections,
        [id]: {
          ...s.sections[id],
          ...(typeof p === 'function' ? p(s.sections[id] || {}) : p)
        }
      }
    })),
    setFocus: slotId => setState(s => ({
      ...s,
      focus: slotId
    }))
  }), [state]);

  // Esc exits focus; any outside pointerdown commits an in-progress rename.
  React.useEffect(() => {
    const onKey = e => {
      if (e.key === 'Escape') api.setFocus(null);
    };
    const onPd = e => {
      const ae = document.activeElement;
      if (ae && ae.isContentEditable && !ae.contains(e.target)) ae.blur();
    };
    document.addEventListener('keydown', onKey);
    document.addEventListener('pointerdown', onPd, true);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.removeEventListener('pointerdown', onPd, true);
    };
  }, [api]);
  return /*#__PURE__*/React.createElement(DCCtx.Provider, {
    value: api
  }, /*#__PURE__*/React.createElement(DCViewport, {
    minScale: minScale,
    maxScale: maxScale,
    style: style
  }, ready && children), state.focus && registry[state.focus] && /*#__PURE__*/React.createElement(DCFocusOverlay, {
    entry: registry[state.focus],
    sectionMeta: sectionMeta,
    sectionOrder: sectionOrder
  }));
}

// ─────────────────────────────────────────────────────────────
// DCViewport — transform-based pan/zoom (internal)
//
// Input mapping (Figma-style):
//   • trackpad pinch  → zoom   (ctrlKey wheel; Safari gesture* events)
//   • trackpad scroll → pan    (two-finger)
//   • mouse wheel     → zoom   (notched; distinguished from trackpad scroll)
//   • middle-drag / primary-drag-on-bg → pan
//
// Transform state lives in a ref and is written straight to the DOM
// (translate3d + will-change) so wheel ticks don't go through React —
// keeps pans at 60fps on dense canvases.
// ─────────────────────────────────────────────────────────────
function DCViewport({
  children,
  minScale = 0.1,
  maxScale = 8,
  style = {}
}) {
  const vpRef = React.useRef(null);
  const worldRef = React.useRef(null);
  const tf = React.useRef({
    x: 0,
    y: 0,
    scale: 1
  });
  // Persist viewport across reloads so the user lands back where they were
  // after an agent edit or browser refresh. The sandbox origin is already
  // per-project; pathname keeps multiple canvas files in one project apart.
  const tfKey = 'dc-viewport:' + location.pathname;
  const saveT = React.useRef(0);
  const lastPostedScale = React.useRef();
  const apply = React.useCallback(() => {
    const {
      x,
      y,
      scale
    } = tf.current;
    const el = worldRef.current;
    if (!el) return;
    el.style.transform = `translate3d(${x}px, ${y}px, 0) scale(${scale})`;
    // Exposed for zoom-invariant chrome (labels, buttons, TweaksPanel).
    el.style.setProperty('--dc-inv-zoom', String(1 / scale));
    // Keep the host toolbar's % readout in sync with the canvas scale. Pan
    // ticks leave scale unchanged — skip the cross-frame post for those.
    if (lastPostedScale.current !== scale) {
      lastPostedScale.current = scale;
      window.parent.postMessage({
        type: '__dc_zoom',
        scale
      }, '*');
    }
    clearTimeout(saveT.current);
    saveT.current = setTimeout(() => {
      try {
        localStorage.setItem(tfKey, JSON.stringify(tf.current));
      } catch {}
    }, 200);
  }, [tfKey]);
  React.useLayoutEffect(() => {
    const flush = () => {
      clearTimeout(saveT.current);
      try {
        localStorage.setItem(tfKey, JSON.stringify(tf.current));
      } catch {}
    };
    try {
      const s = JSON.parse(localStorage.getItem(tfKey) || 'null');
      if (s && Number.isFinite(s.x) && Number.isFinite(s.y) && Number.isFinite(s.scale)) {
        tf.current = {
          x: s.x,
          y: s.y,
          scale: Math.min(maxScale, Math.max(minScale, s.scale))
        };
        apply();
      }
    } catch {}
    // Flush on pagehide and unmount so a reload within the 200ms debounce
    // window doesn't drop the last pan/zoom.
    window.addEventListener('pagehide', flush);
    return () => {
      window.removeEventListener('pagehide', flush);
      flush();
    };
  }, []);
  React.useEffect(() => {
    const vp = vpRef.current;
    if (!vp) return;
    const zoomAt = (cx, cy, factor) => {
      const r = vp.getBoundingClientRect();
      const px = cx - r.left,
        py = cy - r.top;
      const t = tf.current;
      const next = Math.min(maxScale, Math.max(minScale, t.scale * factor));
      const k = next / t.scale;
      // --dc-inv-zoom consumers (.dc-sectionhead's CSS zoom, each section's
      // marginBottom) reflow on every scale change, vertically shifting the
      // world layout — so a world point mathematically pinned under the cursor
      // drifts as you zoom (content creeps up on zoom-in, down on zoom-out).
      // Anchor the DOM element under the cursor instead: record its screen Y,
      // apply the transform + --dc-inv-zoom, then cancel whatever vertical
      // drift the reflow introduced so it stays put on screen.
      let marker = null,
        markerY0 = 0;
      if (k !== 1) {
        const hit = document.elementFromPoint(cx, cy);
        marker = hit && hit.closest ? hit.closest('[data-dc-slot],[data-dc-section]') : null;
        if (marker) markerY0 = marker.getBoundingClientRect().top;
      }
      // keep the world point under the cursor fixed
      t.x = px - (px - t.x) * k;
      t.y = py - (py - t.y) * k;
      t.scale = next;
      apply();
      if (marker) {
        // A pure zoom around (cx, cy) maps screen Y → cy + (Y - cy) * k. Any
        // departure after the --dc-inv-zoom reflow is the layout drift.
        const drift = marker.getBoundingClientRect().top - (cy + (markerY0 - cy) * k);
        if (Math.abs(drift) > 0.1) {
          t.y -= drift;
          apply();
        }
      }
    };

    // Mouse-wheel vs trackpad-scroll heuristic. A physical wheel sends
    // line-mode deltas (Firefox) or large integer pixel deltas with no X
    // component (Chrome/Safari, typically multiples of 100/120). Trackpad
    // two-finger scroll sends small/fractional pixel deltas, often with
    // non-zero deltaX. ctrlKey is set by the browser for trackpad pinch.
    const isMouseWheel = e => e.deltaMode !== 0 || e.deltaX === 0 && Number.isInteger(e.deltaY) && Math.abs(e.deltaY) >= 40;
    const onWheel = e => {
      e.preventDefault();
      if (isGesturing) return; // Safari: gesture* owns the pinch — discard concurrent wheels
      if ((e.ctrlKey || e.metaKey) && !isMouseWheel(e)) {
        // trackpad pinch, or ctrl/cmd + smooth-scroll mouse. Notched
        // wheels fall through to the fixed-step branch below.
        zoomAt(e.clientX, e.clientY, Math.exp(-e.deltaY * 0.01));
      } else if (isMouseWheel(e)) {
        // notched mouse wheel — fixed-ratio step per click
        zoomAt(e.clientX, e.clientY, Math.exp(-Math.sign(e.deltaY) * 0.18));
      } else {
        // trackpad two-finger scroll — pan
        tf.current.x -= e.deltaX;
        tf.current.y -= e.deltaY;
        apply();
      }
    };

    // Safari sends native gesture* events for trackpad pinch with a smooth
    // e.scale; preferring these over the ctrl+wheel fallback gives a much
    // better feel there. No-ops on other browsers. Safari also fires
    // ctrlKey wheel events during the same pinch — isGesturing makes
    // onWheel drop those entirely so they neither zoom nor pan.
    let gsBase = 1;
    let isGesturing = false;
    const onGestureStart = e => {
      e.preventDefault();
      isGesturing = true;
      gsBase = tf.current.scale;
    };
    const onGestureChange = e => {
      e.preventDefault();
      zoomAt(e.clientX, e.clientY, gsBase * e.scale / tf.current.scale);
    };
    const onGestureEnd = e => {
      e.preventDefault();
      isGesturing = false;
    };

    // Drag-pan: middle button anywhere, or primary button on canvas
    // background (anything that isn't an artboard or an inline editor).
    let drag = null;
    const onPointerDown = e => {
      const onBg = !e.target.closest('[data-dc-slot], .dc-editable');
      if (!(e.button === 1 || e.button === 0 && onBg)) return;
      e.preventDefault();
      vp.setPointerCapture(e.pointerId);
      drag = {
        id: e.pointerId,
        lx: e.clientX,
        ly: e.clientY
      };
      vp.style.cursor = 'grabbing';
    };
    const onPointerMove = e => {
      if (!drag || e.pointerId !== drag.id) return;
      tf.current.x += e.clientX - drag.lx;
      tf.current.y += e.clientY - drag.ly;
      drag.lx = e.clientX;
      drag.ly = e.clientY;
      apply();
    };
    const onPointerUp = e => {
      if (!drag || e.pointerId !== drag.id) return;
      vp.releasePointerCapture(e.pointerId);
      drag = null;
      vp.style.cursor = '';
    };

    // Host-driven zoom (toolbar % menu). Zooms around viewport centre so the
    // visible midpoint stays fixed — matching the host's iframe-zoom feel.
    const onHostMsg = e => {
      const d = e.data;
      if (d && d.type === '__dc_set_zoom' && typeof d.scale === 'number') {
        const r = vp.getBoundingClientRect();
        zoomAt(r.left + r.width / 2, r.top + r.height / 2, d.scale / tf.current.scale);
      } else if (d && d.type === '__dc_probe') {
        // Host's [readyGen] reset asks whether a canvas is present; it
        // fires on the iframe's native 'load', which for canvases with
        // images/fonts is after our mount-time announce, so re-announce.
        // Clear the pan-tick guard so apply() re-posts the current scale
        // even if it's unchanged — the host just reset dcScale to 1.
        window.parent.postMessage({
          type: '__dc_present'
        }, '*');
        lastPostedScale.current = undefined;
        apply();
      }
    };
    window.addEventListener('message', onHostMsg);
    // Announce canvas mode so the host toolbar proxies its % control here
    // instead of scaling the iframe element (which would just shrink the
    // viewport window of an infinite canvas). The apply() that follows emits
    // the initial __dc_zoom so the toolbar % is correct before first pinch.
    // lastPostedScale reset mirrors the __dc_probe handler: the layout
    // effect's restore-path apply() may already have posted the restored
    // scale (before __dc_present), so clear the guard to re-post it in order.
    window.parent.postMessage({
      type: '__dc_present'
    }, '*');
    lastPostedScale.current = undefined;
    apply();
    vp.addEventListener('wheel', onWheel, {
      passive: false
    });
    vp.addEventListener('gesturestart', onGestureStart, {
      passive: false
    });
    vp.addEventListener('gesturechange', onGestureChange, {
      passive: false
    });
    vp.addEventListener('gestureend', onGestureEnd, {
      passive: false
    });
    vp.addEventListener('pointerdown', onPointerDown);
    vp.addEventListener('pointermove', onPointerMove);
    vp.addEventListener('pointerup', onPointerUp);
    vp.addEventListener('pointercancel', onPointerUp);
    return () => {
      window.removeEventListener('message', onHostMsg);
      vp.removeEventListener('wheel', onWheel);
      vp.removeEventListener('gesturestart', onGestureStart);
      vp.removeEventListener('gesturechange', onGestureChange);
      vp.removeEventListener('gestureend', onGestureEnd);
      vp.removeEventListener('pointerdown', onPointerDown);
      vp.removeEventListener('pointermove', onPointerMove);
      vp.removeEventListener('pointerup', onPointerUp);
      vp.removeEventListener('pointercancel', onPointerUp);
    };
  }, [apply, minScale, maxScale]);
  const gridSvg = `url("data:image/svg+xml,%3Csvg width='120' height='120' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M120 0H0v120' fill='none' stroke='${encodeURIComponent(DC.grid)}' stroke-width='1'/%3E%3C/svg%3E")`;
  return /*#__PURE__*/React.createElement("div", {
    ref: vpRef,
    className: "design-canvas",
    style: {
      height: '100vh',
      width: '100vw',
      background: DC.bg,
      overflow: 'hidden',
      overscrollBehavior: 'none',
      touchAction: 'none',
      position: 'relative',
      fontFamily: DC.font,
      boxSizing: 'border-box',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    ref: worldRef,
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      transformOrigin: '0 0',
      willChange: 'transform',
      width: 'max-content',
      minWidth: '100%',
      minHeight: '100%',
      padding: '60px 0 80px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: -6000,
      backgroundImage: gridSvg,
      backgroundSize: '120px 120px',
      pointerEvents: 'none',
      zIndex: -1
    }
  }), children));
}

// ─────────────────────────────────────────────────────────────
// DCSection — editable title + h-row of artboards in persisted order
// ─────────────────────────────────────────────────────────────
function DCSection({
  id,
  title,
  subtitle,
  children,
  gap = 48
}) {
  const ctx = React.useContext(DCCtx);
  const sid = id ?? title;
  const all = React.Children.toArray(dcFlatten(children));
  const artboards = all.filter(c => c && c.type === DCArtboard);
  const rest = all.filter(c => !(c && c.type === DCArtboard));
  const sec = ctx && sid && ctx.section(sid) || {};
  // Must match DesignCanvas's srcKey computation exactly (it filters falsy
  // IDs), or onDelete persists a srcKey that DesignCanvas never recognizes.
  const allIds = artboards.map(a => a.props.id ?? a.props.label).filter(Boolean);
  const srcKey = allIds.join('\x1f');
  const hidden = sec.srcKey === srcKey ? sec.hidden || [] : [];
  const srcOrder = allIds.filter(k => !hidden.includes(k));
  const order = React.useMemo(() => {
    const kept = (sec.order || []).filter(k => srcOrder.includes(k));
    return [...kept, ...srcOrder.filter(k => !kept.includes(k))];
  }, [sec.order, srcOrder.join('|')]);
  const byId = Object.fromEntries(artboards.map(a => [a.props.id ?? a.props.label, a]));

  // marginBottom counter-scales so the on-screen gap between sections stays
  // constant — otherwise at low zoom the (world-space) gap collapses while
  // the screen-constant sectionhead below it doesn't, and the title reads as
  // belonging to the section above. paddingBottom below is just enough for
  // the 24px artboard-header (abs-positioned above each card) plus ~8px, so
  // the title sits tight against its own row at every zoom.
  return /*#__PURE__*/React.createElement("div", {
    "data-dc-section": sid,
    style: {
      marginBottom: 'calc(80px * var(--dc-inv-zoom, 1))',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 60px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "dc-sectionhead",
    style: {
      paddingBottom: 36
    }
  }, /*#__PURE__*/React.createElement(DCEditable, {
    tag: "div",
    value: sec.title ?? title,
    onChange: v => ctx && sid && ctx.patchSection(sid, {
      title: v
    }),
    style: {
      fontSize: 28,
      fontWeight: 600,
      color: DC.title,
      letterSpacing: -0.4,
      marginBottom: 6,
      display: 'inline-block'
    }
  }), subtitle && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      color: DC.subtitle
    }
  }, subtitle))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap,
      padding: '0 60px',
      alignItems: 'flex-start',
      width: 'max-content'
    }
  }, order.map(k => /*#__PURE__*/React.createElement(DCArtboardFrame, {
    key: k,
    sectionId: sid,
    artboard: byId[k],
    order: order,
    label: (sec.labels || {})[k] ?? byId[k].props.label,
    onRename: v => ctx && ctx.patchSection(sid, x => ({
      labels: {
        ...x.labels,
        [k]: v
      }
    })),
    onReorder: next => ctx && ctx.patchSection(sid, {
      order: next
    }),
    onDelete: () => ctx && ctx.patchSection(sid, x => ({
      hidden: [...(x.srcKey === srcKey ? x.hidden || [] : []), k],
      srcKey
    })),
    onFocus: () => ctx && ctx.setFocus(`${sid}/${k}`)
  }))), rest);
}

// DCArtboard — marker; rendered by DCArtboardFrame via DCSection.
function DCArtboard() {
  return null;
}

// Per-artboard export (kind: 'png' | 'html'). Both paths share the same
// self-contained clone: computed styles baked in, @font-face / <img> /
// inline-style background-image urls inlined as data URIs. PNG wraps the
// clone in foreignObject→canvas at 3× the artboard's natural width×height
// (same pipeline the host uses for page captures); HTML wraps it in a
// minimal standalone document. Both are independent of viewport zoom.
async function dcExport(node, w, h, name, kind) {
  try {
    await document.fonts.ready;
  } catch {}
  const toDataURL = url => fetch(url).then(r => r.blob()).then(b => new Promise(res => {
    const fr = new FileReader();
    fr.onload = () => res(fr.result);
    fr.onerror = () => res(url);
    fr.readAsDataURL(b);
  })).catch(() => url);

  // Collect @font-face rules. ss.cssRules throws SecurityError on
  // cross-origin sheets (e.g. fonts.googleapis.com) — in that case fetch
  // the CSS text directly (those endpoints send ACAO:*) and regex-extract
  // the blocks. @import and @media/@supports are walked so nested
  // @font-face rules aren't missed.
  const fontRules = [],
    pending = [],
    seen = new Set();
  const scrapeCss = href => {
    if (seen.has(href)) return;
    seen.add(href);
    pending.push(fetch(href).then(r => r.text()).then(css => {
      for (const m of css.match(/@font-face\s*{[^}]*}/g) || []) fontRules.push({
        css: m,
        base: href
      });
      for (const m of css.matchAll(/@import\s+(?:url\()?['"]?([^'")\s;]+)/g)) scrapeCss(new URL(m[1], href).href);
    }).catch(() => {}));
  };
  const walk = (rules, base) => {
    for (const r of rules) {
      if (r.type === CSSRule.FONT_FACE_RULE) fontRules.push({
        css: r.cssText,
        base
      });else if (r.type === CSSRule.IMPORT_RULE && r.styleSheet) {
        const ibase = r.styleSheet.href || base;
        try {
          walk(r.styleSheet.cssRules, ibase);
        } catch {
          scrapeCss(ibase);
        }
      } else if (r.cssRules) walk(r.cssRules, base);
    }
  };
  for (const ss of document.styleSheets) {
    const base = ss.href || location.href;
    try {
      walk(ss.cssRules, base);
    } catch {
      if (ss.href) scrapeCss(ss.href);
    }
  }
  while (pending.length) await pending.shift();
  const fontCss = (await Promise.all(fontRules.map(async rule => {
    let out = rule.css,
      m;
    const re = /url\((['"]?)([^'")]+)\1\)/g;
    while (m = re.exec(rule.css)) {
      if (m[2].indexOf('data:') === 0) continue;
      let abs;
      try {
        abs = new URL(m[2], rule.base).href;
      } catch {
        continue;
      }
      out = out.split(m[0]).join('url("' + (await toDataURL(abs)) + '")');
    }
    return out;
  }))).join('\n');
  const cloneStyled = src => {
    if (src.nodeType === 8 || src.nodeType === 1 && src.tagName === 'SCRIPT') return document.createTextNode('');
    const dst = src.cloneNode(false);
    if (src.nodeType === 1) {
      const cs = getComputedStyle(src);
      let txt = '';
      for (let i = 0; i < cs.length; i++) txt += cs[i] + ':' + cs.getPropertyValue(cs[i]) + ';';
      dst.setAttribute('style', txt + 'animation:none;transition:none;');
      if (src.tagName === 'CANVAS') try {
        const im = document.createElement('img');
        im.src = src.toDataURL();
        im.setAttribute('style', txt);
        return im;
      } catch {}
    }
    for (let c = src.firstChild; c; c = c.nextSibling) dst.appendChild(cloneStyled(c));
    return dst;
  };
  const clone = cloneStyled(node);
  clone.setAttribute('xmlns', 'http://www.w3.org/1999/xhtml');
  // Drop the card's own shadow/radius so the export is a flush w×h rect;
  // the artboard's own background (if any) is already in the computed style.
  clone.style.boxShadow = 'none';
  clone.style.borderRadius = '0';
  const jobs = [];
  clone.querySelectorAll('img').forEach(el => {
    const s = el.getAttribute('src');
    if (s && s.indexOf('data:') !== 0) jobs.push(toDataURL(el.src).then(d => el.setAttribute('src', d)));
  });
  [clone, ...clone.querySelectorAll('*')].forEach(el => {
    const bg = el.style.backgroundImage;
    if (!bg) return;
    let m;
    const re = /url\(["']?([^"')]+)["']?\)/g;
    while (m = re.exec(bg)) {
      const tok = m[0],
        url = m[1];
      if (url.indexOf('data:') === 0) continue;
      jobs.push(toDataURL(url).then(d => {
        el.style.backgroundImage = el.style.backgroundImage.split(tok).join('url("' + d + '")');
      }));
    }
  });
  await Promise.all(jobs);
  const xml = new XMLSerializer().serializeToString(clone);
  const save = (blob, ext) => {
    if (!blob) return;
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name + '.' + ext;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  };
  if (kind === 'html') {
    const html = '<!doctype html><html><head><meta charset="utf-8"><title>' + name + '</title>' + (fontCss ? '<style>' + fontCss + '</style>' : '') + '</head><body style="margin:0">' + xml + '</body></html>';
    return save(new Blob([html], {
      type: 'text/html'
    }), 'html');
  }

  // PNG: the SVG's own width/height must be the output resolution — an
  // <img>-loaded SVG rasterizes at its intrinsic size, so sizing it at 1×
  // and ctx.scale()-ing up would just upscale a 1× bitmap. viewBox maps the
  // w×h foreignObject onto the px·w × px·h SVG canvas so the browser renders
  // the HTML at full resolution.
  const px = 3;
  const svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' + w * px + '" height="' + h * px + '" viewBox="0 0 ' + w + ' ' + h + '"><foreignObject width="' + w + '" height="' + h + '">' + (fontCss ? '<style><![CDATA[' + fontCss + ']]></style>' : '') + xml + '</foreignObject></svg>';
  const img = new Image();
  await new Promise((res, rej) => {
    img.onload = res;
    img.onerror = () => rej(new Error('svg load failed'));
    img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  });
  const cv = document.createElement('canvas');
  cv.width = w * px;
  cv.height = h * px;
  cv.getContext('2d').drawImage(img, 0, 0);
  cv.toBlob(blob => save(blob, 'png'), 'image/png');
}
function DCArtboardFrame({
  sectionId,
  artboard,
  label,
  order,
  onRename,
  onReorder,
  onFocus,
  onDelete
}) {
  const {
    id: rawId,
    label: rawLabel,
    width = 260,
    height = 480,
    children,
    style = {}
  } = artboard.props;
  const id = rawId ?? rawLabel;
  const ref = React.useRef(null);
  const cardRef = React.useRef(null);
  const menuRef = React.useRef(null);
  const [menuOpen, setMenuOpen] = React.useState(false);
  const [confirming, setConfirming] = React.useState(false);

  // ⋯ menu: close on any outside pointerdown. Two-click delete lives inside
  // the menu — first click arms the row, second commits; closing disarms.
  React.useEffect(() => {
    if (!menuOpen) {
      setConfirming(false);
      return;
    }
    const off = e => {
      if (!menuRef.current || !menuRef.current.contains(e.target)) setMenuOpen(false);
    };
    document.addEventListener('pointerdown', off, true);
    return () => document.removeEventListener('pointerdown', off, true);
  }, [menuOpen]);
  const doExport = kind => {
    setMenuOpen(false);
    if (!cardRef.current) return;
    const name = String(label || id || 'artboard').replace(/[^\w\s.-]+/g, '_');
    dcExport(cardRef.current, width, height, name, kind).catch(e => console.error('[design-canvas] export failed:', e));
  };

  // Live drag-reorder: dragged card sticks to cursor; siblings slide into
  // their would-be slots in real time via transforms. DOM order only
  // changes on drop.
  const onGripDown = e => {
    e.preventDefault();
    e.stopPropagation();
    const me = ref.current;
    // translateX is applied in local (pre-scale) space but pointer deltas and
    // getBoundingClientRect().left are screen-space — divide by the viewport's
    // current scale so the dragged card tracks the cursor at any zoom level.
    const scale = me.getBoundingClientRect().width / me.offsetWidth || 1;
    const peers = Array.from(document.querySelectorAll(`[data-dc-section="${sectionId}"] [data-dc-slot]`));
    const homes = peers.map(el => ({
      el,
      id: el.dataset.dcSlot,
      x: el.getBoundingClientRect().left
    }));
    const slotXs = homes.map(h => h.x);
    const startIdx = order.indexOf(id);
    const startX = e.clientX;
    let liveOrder = order.slice();
    me.classList.add('dc-dragging');
    const layout = () => {
      for (const h of homes) {
        if (h.id === id) continue;
        const slot = liveOrder.indexOf(h.id);
        h.el.style.transform = `translateX(${(slotXs[slot] - h.x) / scale}px)`;
      }
    };
    const move = ev => {
      const dx = ev.clientX - startX;
      me.style.transform = `translateX(${dx / scale}px)`;
      const cur = homes[startIdx].x + dx;
      let nearest = 0,
        best = Infinity;
      for (let i = 0; i < slotXs.length; i++) {
        const d = Math.abs(slotXs[i] - cur);
        if (d < best) {
          best = d;
          nearest = i;
        }
      }
      if (liveOrder.indexOf(id) !== nearest) {
        liveOrder = order.filter(k => k !== id);
        liveOrder.splice(nearest, 0, id);
        layout();
      }
    };
    const up = () => {
      document.removeEventListener('pointermove', move);
      document.removeEventListener('pointerup', up);
      const finalSlot = liveOrder.indexOf(id);
      me.classList.remove('dc-dragging');
      me.style.transform = `translateX(${(slotXs[finalSlot] - homes[startIdx].x) / scale}px)`;
      // After the settle transition, kill transitions + clear transforms +
      // commit the reorder in the same frame so there's no visual snap-back.
      setTimeout(() => {
        for (const h of homes) {
          h.el.style.transition = 'none';
          h.el.style.transform = '';
        }
        if (liveOrder.join('|') !== order.join('|')) onReorder(liveOrder);
        requestAnimationFrame(() => requestAnimationFrame(() => {
          for (const h of homes) h.el.style.transition = '';
        }));
      }, 180);
    };
    document.addEventListener('pointermove', move);
    document.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    "data-dc-slot": id,
    style: {
      position: 'relative',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "dc-header",
    "data-omelette-chrome": "",
    style: {
      color: DC.label
    },
    onPointerDown: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    className: "dc-labelrow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dc-grip",
    onPointerDown: onGripDown,
    title: "Drag to reorder"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "9",
    height: "13",
    viewBox: "0 0 9 13",
    fill: "currentColor"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "2",
    cy: "2",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "7",
    cy: "2",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "2",
    cy: "6.5",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "7",
    cy: "6.5",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "2",
    cy: "11",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "7",
    cy: "11",
    r: "1.1"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "dc-labeltext",
    onClick: onFocus,
    title: "Click to focus"
  }, /*#__PURE__*/React.createElement(DCEditable, {
    value: label,
    onChange: onRename,
    onClick: e => e.stopPropagation(),
    style: {
      fontSize: 15,
      fontWeight: 500,
      color: DC.label,
      lineHeight: 1
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "dc-btns"
  }, /*#__PURE__*/React.createElement("div", {
    ref: menuRef,
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "dc-kebab",
    title: "More",
    onClick: () => setMenuOpen(o => !o)
  }, /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 12 12",
    fill: "currentColor"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "2.5",
    cy: "6",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "6",
    cy: "6",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "9.5",
    cy: "6",
    r: "1.1"
  }))), menuOpen && /*#__PURE__*/React.createElement("div", {
    className: "dc-menu",
    onPointerDown: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => doExport('png')
  }, "Download PNG"), /*#__PURE__*/React.createElement("button", {
    onClick: () => doExport('html')
  }, "Download HTML"), /*#__PURE__*/React.createElement("hr", null), /*#__PURE__*/React.createElement("button", {
    className: "dc-danger",
    onClick: () => {
      if (confirming) {
        setMenuOpen(false);
        onDelete();
      } else setConfirming(true);
    }
  }, confirming ? 'Click again to delete' : 'Delete'))), /*#__PURE__*/React.createElement("button", {
    className: "dc-expand",
    onClick: onFocus,
    title: "Focus"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 12 12",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.6",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M7 1h4v4M5 11H1V7M11 1L7.5 4.5M1 11l3.5-3.5"
  }))))), /*#__PURE__*/React.createElement("div", {
    ref: cardRef,
    className: "dc-card",
    style: {
      borderRadius: 2,
      boxShadow: '0 1px 3px rgba(0,0,0,.08),0 4px 16px rgba(0,0,0,.06)',
      overflow: 'hidden',
      width,
      height,
      background: '#fff',
      ...style
    }
  }, children || /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#bbb',
      fontSize: 13,
      fontFamily: DC.font
    }
  }, id)));
}

// Inline rename — commits on blur or Enter.
function DCEditable({
  value,
  onChange,
  style,
  tag = 'span',
  onClick
}) {
  const T = tag;
  return /*#__PURE__*/React.createElement(T, {
    className: "dc-editable",
    contentEditable: true,
    suppressContentEditableWarning: true,
    onClick: onClick,
    onPointerDown: e => e.stopPropagation(),
    onBlur: e => onChange && onChange(e.currentTarget.textContent),
    onKeyDown: e => {
      if (e.key === 'Enter') {
        e.preventDefault();
        e.currentTarget.blur();
      }
    },
    style: style
  }, value);
}

// ─────────────────────────────────────────────────────────────
// Focus mode — overlay one artboard; ←/→ within section, ↑/↓ across
// sections, Esc or backdrop click to exit.
// ─────────────────────────────────────────────────────────────
function DCFocusOverlay({
  entry,
  sectionMeta,
  sectionOrder
}) {
  const ctx = React.useContext(DCCtx);
  const {
    sectionId,
    artboard
  } = entry;
  const sec = ctx.section(sectionId);
  const meta = sectionMeta[sectionId];
  const peers = meta.slotIds;
  const aid = artboard.props.id ?? artboard.props.label;
  const idx = peers.indexOf(aid);
  const secIdx = sectionOrder.indexOf(sectionId);
  const go = d => {
    const n = peers[(idx + d + peers.length) % peers.length];
    if (n) ctx.setFocus(`${sectionId}/${n}`);
  };
  const goSection = d => {
    // Sections whose artboards are all deleted have slotIds:[] — step past
    // them to the next non-empty section so ↑/↓ doesn't dead-end.
    const n = sectionOrder.length;
    for (let i = 1; i < n; i++) {
      const ns = sectionOrder[((secIdx + d * i) % n + n) % n];
      const first = sectionMeta[ns] && sectionMeta[ns].slotIds[0];
      if (first) {
        ctx.setFocus(`${ns}/${first}`);
        return;
      }
    }
  };
  React.useEffect(() => {
    const k = e => {
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        go(-1);
      }
      if (e.key === 'ArrowRight') {
        e.preventDefault();
        go(1);
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        goSection(-1);
      }
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        goSection(1);
      }
    };
    document.addEventListener('keydown', k);
    return () => document.removeEventListener('keydown', k);
  });
  const {
    width = 260,
    height = 480,
    children
  } = artboard.props;
  const [vp, setVp] = React.useState({
    w: window.innerWidth,
    h: window.innerHeight
  });
  React.useEffect(() => {
    const r = () => setVp({
      w: window.innerWidth,
      h: window.innerHeight
    });
    window.addEventListener('resize', r);
    return () => window.removeEventListener('resize', r);
  }, []);
  const scale = Math.max(0.1, Math.min((vp.w - 200) / width, (vp.h - 260) / height, 2));
  const [ddOpen, setDd] = React.useState(false);
  const Arrow = ({
    dir,
    onClick
  }) => /*#__PURE__*/React.createElement("button", {
    onClick: e => {
      e.stopPropagation();
      onClick();
    },
    style: {
      position: 'absolute',
      top: '50%',
      [dir]: 28,
      transform: 'translateY(-50%)',
      border: 'none',
      background: 'rgba(255,255,255,.08)',
      color: 'rgba(255,255,255,.9)',
      width: 44,
      height: 44,
      borderRadius: 22,
      fontSize: 18,
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'background .15s'
    },
    onMouseEnter: e => e.currentTarget.style.background = 'rgba(255,255,255,.18)',
    onMouseLeave: e => e.currentTarget.style.background = 'rgba(255,255,255,.08)'
  }, /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 18 18",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: dir === 'left' ? 'M11 3L5 9l6 6' : 'M7 3l6 6-6 6'
  })));

  // Portal to body so position:fixed is the real viewport regardless of any
  // transform on DesignCanvas's ancestors (including the canvas zoom itself).
  return ReactDOM.createPortal(/*#__PURE__*/React.createElement("div", {
    onClick: () => ctx.setFocus(null),
    onWheel: e => e.preventDefault(),
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 100,
      background: 'rgba(24,20,16,.6)',
      backdropFilter: 'blur(14px)',
      fontFamily: DC.font,
      color: '#fff'
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      height: 72,
      display: 'flex',
      alignItems: 'flex-start',
      padding: '16px 20px 0',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setDd(o => !o),
    style: {
      border: 'none',
      background: 'transparent',
      color: '#fff',
      cursor: 'pointer',
      padding: '6px 8px',
      borderRadius: 6,
      textAlign: 'left',
      fontFamily: 'inherit'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 18,
      fontWeight: 600,
      letterSpacing: -0.3
    }
  }, meta.title), /*#__PURE__*/React.createElement("svg", {
    width: "11",
    height: "11",
    viewBox: "0 0 11 11",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.8",
    strokeLinecap: "round",
    style: {
      opacity: .7
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M2 4l3.5 3.5L9 4"
  }))), meta.subtitle && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontSize: 13,
      opacity: .6,
      fontWeight: 400,
      marginTop: 2
    }
  }, meta.subtitle)), ddOpen && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: '100%',
      left: 0,
      marginTop: 4,
      background: '#2a251f',
      borderRadius: 8,
      boxShadow: '0 8px 32px rgba(0,0,0,.4)',
      padding: 4,
      minWidth: 200,
      zIndex: 10
    }
  }, sectionOrder.filter(sid => sectionMeta[sid].slotIds.length).map(sid => /*#__PURE__*/React.createElement("button", {
    key: sid,
    onClick: () => {
      setDd(false);
      const f = sectionMeta[sid].slotIds[0];
      if (f) ctx.setFocus(`${sid}/${f}`);
    },
    style: {
      display: 'block',
      width: '100%',
      textAlign: 'left',
      border: 'none',
      cursor: 'pointer',
      background: sid === sectionId ? 'rgba(255,255,255,.1)' : 'transparent',
      color: '#fff',
      padding: '8px 12px',
      borderRadius: 5,
      fontSize: 14,
      fontWeight: sid === sectionId ? 600 : 400,
      fontFamily: 'inherit'
    }
  }, sectionMeta[sid].title)))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("button", {
    onClick: () => ctx.setFocus(null),
    onMouseEnter: e => e.currentTarget.style.background = 'rgba(255,255,255,.12)',
    onMouseLeave: e => e.currentTarget.style.background = 'transparent',
    style: {
      border: 'none',
      background: 'transparent',
      color: 'rgba(255,255,255,.7)',
      width: 32,
      height: 32,
      borderRadius: 16,
      fontSize: 20,
      cursor: 'pointer',
      lineHeight: 1,
      transition: 'background .12s'
    }
  }, "\xD7")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 64,
      bottom: 56,
      left: 100,
      right: 100,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      width: width * scale,
      height: height * scale,
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width,
      height,
      transform: `scale(${scale})`,
      transformOrigin: 'top left',
      background: '#fff',
      borderRadius: 2,
      overflow: 'hidden',
      boxShadow: '0 20px 80px rgba(0,0,0,.4)'
    }
  }, children || /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#bbb'
    }
  }, aid))), /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      fontSize: 14,
      fontWeight: 500,
      opacity: .85,
      textAlign: 'center'
    }
  }, (sec.labels || {})[aid] ?? artboard.props.label, /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: .5,
      marginLeft: 10,
      fontVariantNumeric: 'tabular-nums'
    }
  }, idx + 1, " / ", peers.length))), /*#__PURE__*/React.createElement(Arrow, {
    dir: "left",
    onClick: () => go(-1)
  }), /*#__PURE__*/React.createElement(Arrow, {
    dir: "right",
    onClick: () => go(1)
  }), /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      position: 'absolute',
      bottom: 20,
      left: '50%',
      transform: 'translateX(-50%)',
      display: 'flex',
      gap: 8
    }
  }, peers.map((p, i) => /*#__PURE__*/React.createElement("button", {
    key: p,
    onClick: () => ctx.setFocus(`${sectionId}/${p}`),
    style: {
      border: 'none',
      padding: 0,
      cursor: 'pointer',
      width: 6,
      height: 6,
      borderRadius: 3,
      background: i === idx ? '#fff' : 'rgba(255,255,255,.3)'
    }
  })))), document.body);
}

// ─────────────────────────────────────────────────────────────
// Post-it — absolute-positioned sticky note
// ─────────────────────────────────────────────────────────────
function DCPostIt({
  children,
  top,
  left,
  right,
  bottom,
  rotate = -2,
  width = 180
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top,
      left,
      right,
      bottom,
      width,
      background: DC.postitBg,
      padding: '14px 16px',
      fontFamily: '"Comic Sans MS", "Marker Felt", "Segoe Print", cursive',
      fontSize: 14,
      lineHeight: 1.4,
      color: DC.postitText,
      boxShadow: '0 2px 8px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.08)',
      transform: `rotate(${rotate}deg)`,
      zIndex: 5
    }
  }, children);
}
Object.assign(window, {
  DesignCanvas,
  DCSection,
  DCArtboard,
  DCPostIt
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "design-canvas.jsx", error: String((e && e.message) || e) }); }

// emails.js
try { (() => {
/* =========================================================================
   WareSpace Email Builder — logic
   -------------------------------------------------------------------------
   Renders HubSpot-ready, Outlook-safe email HTML from a template spec +
   user-entered field values. Each template defines:
     · title         — editor heading
     · subject       — default HubSpot subject line (supports merge tags)
     · preview       — default preheader text
     · fromName      — default sender
     · fields[]      — which form inputs to show
     · defaults{}    — default values for those fields
     · render(v)     — returns the email body HTML (table-based)
   ========================================================================= */

// Brand tokens — must match tokens.css, but INLINED (email clients ignore <link>).
const WS = {
  green: "#00AA6C",
  greenDark: "#0B8E5F",
  green40: "#E6F4EB",
  green70: "#AEDABD",
  navy: "#102442",
  navy80: "#1C274C",
  bright: "#20D291",
  mustard: "#F0B944",
  sun: "#F0CE5C",
  pink: "#E55177",
  white: "#FFFFFF",
  gray100: "#F8F8F9",
  gray120: "#F1F1F1",
  gray160: "#DCDCDC",
  gray400: "#8A8A8A",
  black: "#000000"
};
const ACCENTS = [{
  key: "green",
  hex: WS.green,
  label: "Primary Green"
}, {
  key: "bright",
  hex: WS.bright,
  label: "Bright Green"
}, {
  key: "navy",
  hex: WS.navy,
  label: "Navy"
}, {
  key: "mustard",
  hex: WS.mustard,
  label: "Mustard"
}, {
  key: "pink",
  hex: WS.pink,
  label: "Pink"
}];

/* -------------------------------------------------------------------------
   HELPERS — shared HTML fragments every template can reuse
   ------------------------------------------------------------------------- */

function emailDoc({
  subject,
  preview,
  bodyHtml,
  bg = WS.gray120
}) {
  return `<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<meta name="x-apple-disable-message-reformatting"/>
<title>${esc(subject)}</title>
<!--[if mso]><xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml><![endif]-->
<style type="text/css">
  body, table, td, a { -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%; }
  table, td { mso-table-lspace:0pt; mso-table-rspace:0pt; }
  img { -ms-interpolation-mode:bicubic; border:0; outline:none; text-decoration:none; }
  body { margin:0!important; padding:0!important; width:100%!important; background:${bg}; }
  a { color:${WS.green}; text-decoration:underline; }
  @media screen and (max-width:620px){
    .ws-container { width:100%!important; }
    .ws-px { padding-left:24px!important; padding-right:24px!important; }
    .ws-h1 { font-size:32px!important; line-height:1.1!important; }
    .ws-h2 { font-size:24px!important; }
    .ws-stack { display:block!important; width:100%!important; }
  }
</style>
</head>
<body style="margin:0;padding:0;background:${bg};font-family:Arial,Helvetica,sans-serif;color:${WS.black};">
  <div style="display:none;max-height:0;overflow:hidden;mso-hide:all;font-size:1px;line-height:1px;color:${bg};">
    ${esc(preview)}&nbsp;&#847;&zwnj;&nbsp;&#847;&zwnj;&nbsp;&#847;&zwnj;&nbsp;&#847;&zwnj;&nbsp;&#847;&zwnj;&nbsp;&#847;&zwnj;
  </div>
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="${bg}">
    <tr><td align="center" style="padding:32px 12px;">
      <table role="presentation" class="ws-container" width="600" cellpadding="0" cellspacing="0" border="0" style="width:600px;max-width:600px;background:${WS.white};border-radius:4px;">
        ${bodyHtml}
      </table>
      <table role="presentation" class="ws-container" width="600" cellpadding="0" cellspacing="0" border="0" style="width:600px;max-width:600px;margin-top:24px;">
        <tr><td class="ws-px" align="center" style="padding:8px 32px;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.6;color:${WS.gray400};">
          WareSpace &nbsp;·&nbsp; 555 Innovation Way, Austin TX 78701<br/>
          You received this email because you signed up for WareSpace updates.<br/>
          <a href="{{unsubscribe_link}}" style="color:${WS.gray400};text-decoration:underline;">Unsubscribe</a>
          &nbsp;·&nbsp;
          <a href="{{email_preferences_url}}" style="color:${WS.gray400};text-decoration:underline;">Preferences</a>
          &nbsp;·&nbsp;
          <a href="https://warespace.com" style="color:${WS.gray400};text-decoration:underline;">warespace.com</a>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;
}
function headerRow({
  variant = "light"
} = {}) {
  const bg = variant === "dark" ? WS.navy : WS.white;
  const logoSrc = variant === "dark" ? "https://warespace.com/brand/horizontal-white.png" : "https://warespace.com/brand/horizontal-color.png";
  return `
  <tr><td class="ws-px" align="left" style="padding:28px 40px 20px;background:${bg};">
    <img src="${logoSrc}" alt="WareSpace" width="180" height="26" style="display:block;height:26px;width:auto;border:0;"/>
  </td></tr>`;
}
function ctaButton({
  label,
  url,
  bg = WS.green,
  fg = WS.white
}) {
  return `
  <table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:8px 0;">
    <tr><td bgcolor="${bg}" style="border-radius:999px;">
      <a href="${esc(url)}" style="display:inline-block;padding:16px 36px;font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:16px;line-height:1;color:${fg};text-decoration:none;border-radius:999px;background:${bg};">
        ${esc(label)}
      </a>
    </td></tr>
  </table>`;
}
function divider(color = WS.gray160) {
  return `
  <tr><td class="ws-px" style="padding:0 40px;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
      <tr><td style="border-top:1px solid ${color};font-size:0;line-height:0;height:1px;">&nbsp;</td></tr>
    </table>
  </td></tr>`;
}
function spacer(px = 24) {
  return `<tr><td style="font-size:0;line-height:0;height:${px}px;">&nbsp;</td></tr>`;
}
function esc(s) {
  if (s == null) return "";
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function fmtDate(d) {
  if (!d) return "";
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(d);
  if (!m) return d;
  const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const dt = new Date(+m[1], +m[2] - 1, +m[3]);
  const day = dt.getDate();
  const wkday = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][dt.getDay()];
  return `${wkday}, ${months[+m[2] - 1]} ${day}`;
}

/* -------------------------------------------------------------------------
   TEMPLATES
   ------------------------------------------------------------------------- */

const TEMPLATES = {
  // ── WELCOME — new prospect signed up (top-of-funnel) ───────────────────
  "welcome-prospect": {
    title: "Welcome — new subscriber",
    subject: "Welcome to WareSpace, {{first_name}}",
    preview: "Flexible industrial space for growing businesses. Here's how we can help.",
    fromName: "The WareSpace Team",
    fields: [{
      id: "first_name",
      label: "First name (merge tag)",
      kind: "text"
    }, {
      id: "headline",
      label: "Headline",
      kind: "text"
    }, {
      id: "intro",
      label: "Intro paragraph",
      kind: "textarea"
    }, {
      id: "bullet_1",
      label: "Bullet 1",
      kind: "text"
    }, {
      id: "bullet_2",
      label: "Bullet 2",
      kind: "text"
    }, {
      id: "bullet_3",
      label: "Bullet 3",
      kind: "text"
    }, {
      id: "cta_label",
      label: "CTA label",
      kind: "text"
    }, {
      id: "cta_url",
      label: "CTA URL",
      kind: "url"
    }],
    defaults: {
      first_name: "{{contact.firstname}}",
      headline: "Welcome to WareSpace.",
      intro: "You're on the list. We build flex-industrial buildings designed for the way small businesses actually work — bay doors, clear heights, real loading, and neighbors in your same boat.",
      bullet_1: "15 buildings across 8 metros, and growing",
      bullet_2: "Units from 800 to 12,000 sq ft",
      bullet_3: "Month-to-month tours, no pressure",
      cta_label: "Browse buildings",
      cta_url: "{{cta_url}}"
    },
    render(v) {
      const body = `
        ${headerRow()}
        <tr><td class="ws-px" style="padding:48px 40px 16px;">
          <div style="font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:12px;letter-spacing:2px;text-transform:uppercase;color:${WS.green};">Hello there</div>
          <h1 class="ws-h1" style="margin:12px 0 14px;font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:40px;line-height:1.05;color:${WS.black};letter-spacing:-0.5px;">${esc(v.headline)}</h1>
          <p style="margin:0;font-family:Arial,Helvetica,sans-serif;font-size:16px;line-height:1.7;color:${WS.black};">Hi ${esc(v.first_name)},</p>
          <p style="margin:12px 0 0;font-family:Arial,Helvetica,sans-serif;font-size:16px;line-height:1.7;color:${WS.black};">${esc(v.intro)}</p>
        </td></tr>
        <tr><td class="ws-px" style="padding:24px 40px 8px;">
          ${[v.bullet_1, v.bullet_2, v.bullet_3].filter(Boolean).map(t => `
            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="margin:0 0 10px;"><tr>
              <td valign="top" width="32" style="padding:4px 0;">
                <div style="width:20px;height:20px;background:${WS.green};border-radius:999px;color:${WS.white};font-family:Arial,Helvetica,sans-serif;font-size:12px;text-align:center;line-height:20px;">✓</div>
              </td>
              <td valign="middle" style="padding:2px 0;font-family:Arial,Helvetica,sans-serif;font-size:15.5px;line-height:1.55;color:${WS.black};">${esc(t)}</td>
            </tr></table>
          `).join("")}
        </td></tr>
        <tr><td class="ws-px" align="left" style="padding:24px 40px 48px;">
          ${ctaButton({
        label: v.cta_label,
        url: v.cta_url
      })}
        </td></tr>
      `;
      return emailDoc({
        subject: interpolate(this.subject, v),
        preview: interpolate(this.preview, v),
        bodyHtml: body
      });
    }
  },
  // ── TOUR FOLLOW-UP — post-tour, salesy but warm ─────────────────────────
  "tour-followup": {
    title: "Tour follow-up",
    subject: "Great meeting you at {{property_name}}",
    preview: "Here's the space info we talked about, plus next steps.",
    fromName: "{{owner.first_name}} at WareSpace",
    fields: [{
      id: "first_name",
      label: "Contact first name",
      kind: "text"
    }, {
      id: "rep_name",
      label: "Your name",
      kind: "text"
    }, {
      id: "property_name",
      label: "Property",
      kind: "text"
    }, {
      id: "unit_size",
      label: "Unit(s) discussed",
      kind: "text"
    }, {
      id: "price_range",
      label: "Price range",
      kind: "text"
    }, {
      id: "notes",
      label: "Personal note",
      kind: "textarea"
    }, {
      id: "cta_label",
      label: "Primary CTA",
      kind: "text"
    }, {
      id: "cta_url",
      label: "CTA URL",
      kind: "url"
    }, {
      id: "cta2_label",
      label: "Secondary CTA",
      kind: "text"
    }, {
      id: "cta2_url",
      label: "Secondary URL",
      kind: "url"
    }],
    defaults: {
      first_name: "{{contact.firstname}}",
      rep_name: "Jordan",
      property_name: "The Works on 5th",
      unit_size: "Unit 204 · 2,400 sq ft",
      price_range: "$2.80 – $3.10 / sq ft / month, NNN",
      notes: "Really enjoyed the walkthrough this morning. Unit 204 had the clear height and the drive-up you asked about — and Unit 118 is a solid plan B if you want to be closer to the loading dock.",
      cta_label: "Request a proposal",
      cta_url: "{{cta_url}}",
      cta2_label: "Pick a second tour time",
      cta2_url: "{{cta_url}}"
    },
    render(v) {
      const body = `
        ${headerRow()}
        <tr><td class="ws-px" style="padding:44px 40px 12px;">
          <h1 class="ws-h1" style="margin:0;font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:32px;line-height:1.15;color:${WS.black};letter-spacing:-0.3px;">
            Thanks for coming by, ${esc(v.first_name)}.
          </h1>
          <p style="margin:18px 0 0;font-family:Arial,Helvetica,sans-serif;font-size:16px;line-height:1.65;color:${WS.black};">
            ${esc(v.notes)}
          </p>
        </td></tr>
        <tr><td class="ws-px" style="padding:20px 40px 0;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="${WS.gray100}" style="background:${WS.gray100};border-radius:10px;border:1px solid ${WS.gray160};">
            <tr><td style="padding:20px 24px;font-family:Arial,Helvetica,sans-serif;">
              <div style="font-weight:700;font-size:11px;letter-spacing:1.5px;text-transform:uppercase;color:${WS.gray400};">Recap</div>
              <div style="font-weight:700;font-size:17px;color:${WS.black};margin-top:6px;">${esc(v.property_name)}</div>
              <div style="font-size:14px;color:${WS.black};margin-top:4px;line-height:1.6;">${esc(v.unit_size)}<br/><span style="color:${WS.gray400};">${esc(v.price_range)}</span></div>
            </td></tr>
          </table>
        </td></tr>
        <tr><td class="ws-px" align="left" style="padding:28px 40px 8px;">
          ${ctaButton({
        label: v.cta_label,
        url: v.cta_url
      })}
        </td></tr>
        <tr><td class="ws-px" align="left" style="padding:4px 40px 40px;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.6;color:${WS.gray400};">
          Or — <a href="${esc(v.cta2_url)}" style="color:${WS.green};font-weight:700;">${esc(v.cta2_label)}</a>. I'll make it work.<br/><br/>
          — ${esc(v.rep_name)}
        </td></tr>
      `;
      return emailDoc({
        subject: interpolate(this.subject, v),
        preview: interpolate(this.preview, v),
        bodyHtml: body
      });
    }
  },
  // ── BUILDING LAUNCH — broadcast, hero image, stats, amenities ───────────
  "building-launch": {
    title: "New building launch",
    subject: "New in {{city}}: {{property_name}} is now leasing",
    preview: "Tours start {{tour_start_date}}. {{sqft}} sq ft of flex-industrial space.",
    fromName: "WareSpace",
    fields: [{
      id: "city",
      label: "City",
      kind: "text"
    }, {
      id: "property_name",
      label: "Property name",
      kind: "text"
    }, {
      id: "hero_image",
      label: "Hero image URL",
      kind: "url"
    }, {
      id: "summary",
      label: "Summary",
      kind: "textarea"
    }, {
      id: "sqft",
      label: "Total sq ft",
      kind: "text"
    }, {
      id: "units",
      label: "Unit range",
      kind: "text"
    }, {
      id: "amenity_1",
      label: "Amenity 1",
      kind: "text"
    }, {
      id: "amenity_2",
      label: "Amenity 2",
      kind: "text"
    }, {
      id: "amenity_3",
      label: "Amenity 3",
      kind: "text"
    }, {
      id: "tour_start_date",
      label: "Tour start date",
      kind: "text"
    }, {
      id: "cta_label",
      label: "CTA label",
      kind: "text"
    }, {
      id: "cta_url",
      label: "CTA URL",
      kind: "url"
    }],
    defaults: {
      city: "Austin",
      property_name: "The Works on 5th",
      hero_image: "assets/photos/photo-03.jpg",
      summary: "A 160,000 sq ft flex-industrial building a mile east of downtown. Drive-up loading, 22-ft clear heights, and a covered courtyard for team lunches.",
      sqft: "160,000",
      units: "800 – 12,000 sq ft",
      amenity_1: "Drive-up loading docks",
      amenity_2: "22-ft clear heights",
      amenity_3: "On-site shared conference rooms",
      tour_start_date: "May 20",
      cta_label: "Book a tour",
      cta_url: "{{cta_url}}"
    },
    render(v) {
      const body = `
        ${headerRow()}
        <tr><td style="font-size:0;line-height:0;">
          <img src="${esc(v.hero_image)}" alt="${esc(v.property_name)}" width="600" style="display:block;width:100%;max-width:600px;height:auto;border:0;"/>
        </td></tr>
        <tr><td class="ws-px" style="padding:36px 40px 12px;">
          <div style="font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:12px;letter-spacing:2px;text-transform:uppercase;color:${WS.green};">Now leasing · ${esc(v.city)}</div>
          <h1 class="ws-h1" style="margin:10px 0 14px;font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:34px;line-height:1.1;color:${WS.black};letter-spacing:-0.5px;">${esc(v.property_name)}</h1>
          <p style="margin:0;font-family:Arial,Helvetica,sans-serif;font-size:16px;line-height:1.65;color:${WS.black};">${esc(v.summary)}</p>
        </td></tr>
        <tr><td class="ws-px" style="padding:24px 40px 8px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="${WS.navy}" style="background:${WS.navy};border-radius:10px;">
            <tr>
              <td class="ws-stack" width="50%" valign="top" style="padding:24px;font-family:Arial,Helvetica,sans-serif;color:${WS.white};border-right:1px solid rgba(255,255,255,.12);">
                <div style="font-weight:700;font-size:11px;letter-spacing:1.5px;text-transform:uppercase;opacity:.7;">Total sq ft</div>
                <div style="font-weight:700;font-size:28px;margin-top:6px;">${esc(v.sqft)}</div>
              </td>
              <td class="ws-stack" width="50%" valign="top" style="padding:24px;font-family:Arial,Helvetica,sans-serif;color:${WS.white};">
                <div style="font-weight:700;font-size:11px;letter-spacing:1.5px;text-transform:uppercase;opacity:.7;">Units</div>
                <div style="font-weight:700;font-size:18px;margin-top:6px;line-height:1.3;">${esc(v.units)}</div>
              </td>
            </tr>
          </table>
        </td></tr>
        <tr><td class="ws-px" style="padding:16px 40px 0;">
          <div style="font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:11px;letter-spacing:2px;text-transform:uppercase;color:${WS.gray400};margin-bottom:12px;">What's inside</div>
          ${[v.amenity_1, v.amenity_2, v.amenity_3].filter(Boolean).map(a => `
            <div style="padding:10px 0;font-family:Arial,Helvetica,sans-serif;font-size:15px;color:${WS.black};border-bottom:1px solid ${WS.gray160};">
              <span style="display:inline-block;width:18px;height:18px;background:${WS.green};border-radius:999px;color:${WS.white};font-size:11px;text-align:center;line-height:18px;margin-right:10px;vertical-align:middle;">✓</span>${esc(a)}
            </div>
          `).join("")}
        </td></tr>
        <tr><td class="ws-px" align="left" style="padding:32px 40px 12px;">
          <div style="font-family:Arial,Helvetica,sans-serif;font-size:14px;color:${WS.gray400};margin-bottom:14px;">Tours start <b style="color:${WS.black};">${esc(v.tour_start_date)}</b>.</div>
          ${ctaButton({
        label: v.cta_label,
        url: v.cta_url
      })}
        </td></tr>
        ${spacer(32)}
      `;
      return emailDoc({
        subject: interpolate(this.subject, v),
        preview: interpolate(this.preview, v),
        bodyHtml: body
      });
    }
  },
  // ── TENANT SPOTLIGHT — editorial, dark, photo-led ───────────────────────
  "tenant-spotlight": {
    title: "Tenant spotlight",
    subject: "{{tenant_name}}: {{tagline}}",
    preview: "Meet {{tenant_name}} — built inside WareSpace.",
    fromName: "WareSpace",
    fields: [{
      id: "tenant_name",
      label: "Tenant / company",
      kind: "text"
    }, {
      id: "tagline",
      label: "Short tagline",
      kind: "text"
    }, {
      id: "tenant_photo",
      label: "Tenant photo URL",
      kind: "url"
    }, {
      id: "quote",
      label: "Pull quote",
      kind: "textarea"
    }, {
      id: "quote_author",
      label: "Quote attribution",
      kind: "text"
    }, {
      id: "story",
      label: "Story body",
      kind: "textarea"
    }, {
      id: "building_name",
      label: "Building they're in",
      kind: "text"
    }, {
      id: "sqft",
      label: "Their sq ft",
      kind: "text"
    }, {
      id: "cta_label",
      label: "CTA label",
      kind: "text"
    }, {
      id: "cta_url",
      label: "CTA URL",
      kind: "url"
    }],
    defaults: {
      tenant_name: "Northside Brewing Co.",
      tagline: "Craft beer, made in East Austin",
      tenant_photo: "assets/photos/photo-04.jpg",
      quote: "When we walked into the space, we knew. High ceilings, loading dock right there, and a team that actually got what a brewery needs. We signed by Friday.",
      quote_author: "Maya Chen, Founder",
      story: "Maya and her team make small-batch beer for Austin taprooms. After outgrowing their kitchen setup, they moved into a flex bay at The Works on 5th — room for fermentation tanks, a tasting nook, and a loading dock for weekly kegs out.",
      building_name: "The Works on 5th",
      sqft: "4,200",
      cta_label: "Read the full story",
      cta_url: "{{cta_url}}"
    },
    render(v) {
      const body = `
        ${headerRow({
        variant: "dark"
      })}
        <tr><td bgcolor="${WS.navy}" style="background:${WS.navy};padding:48px 40px 40px;" class="ws-px">
          <div style="font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:12px;letter-spacing:2px;text-transform:uppercase;color:${WS.bright};">Tenant spotlight</div>
          <h1 class="ws-h1" style="margin:12px 0 8px;font-family:Arial,Helvetica,sans-serif;font-weight:800;font-size:44px;line-height:1;color:${WS.white};letter-spacing:-1px;">${esc(v.tenant_name)}</h1>
          <p style="margin:0;font-family:Arial,Helvetica,sans-serif;font-size:17px;line-height:1.5;color:${WS.white};opacity:.75;">${esc(v.tagline)}</p>
        </td></tr>
        <tr><td style="font-size:0;line-height:0;">
          <img src="${esc(v.tenant_photo)}" alt="${esc(v.tenant_name)}" width="600" style="display:block;width:100%;max-width:600px;height:auto;border:0;"/>
        </td></tr>
        <tr><td class="ws-px" style="padding:36px 40px 0;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
            <tr>
              <td class="ws-stack" width="50%" valign="top" style="padding-right:12px;font-family:Arial,Helvetica,sans-serif;">
                <div style="font-weight:700;font-size:11px;letter-spacing:1.5px;text-transform:uppercase;color:${WS.gray400};">Home base</div>
                <div style="font-size:16px;color:${WS.black};font-weight:600;margin-top:4px;">${esc(v.building_name)}</div>
              </td>
              <td class="ws-stack" width="50%" valign="top" style="padding-left:12px;font-family:Arial,Helvetica,sans-serif;">
                <div style="font-weight:700;font-size:11px;letter-spacing:1.5px;text-transform:uppercase;color:${WS.gray400};">Footprint</div>
                <div style="font-size:16px;color:${WS.black};font-weight:600;margin-top:4px;">${esc(v.sqft)} sq ft</div>
              </td>
            </tr>
          </table>
        </td></tr>
        <tr><td class="ws-px" style="padding:28px 40px 0;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="${WS.green40}" style="background:${WS.green40};border-radius:10px;">
            <tr><td style="padding:26px 28px;font-family:Arial,Helvetica,sans-serif;">
              <div style="font-family:Georgia,'Times New Roman',serif;font-size:40px;line-height:1;color:${WS.green};">"</div>
              <p style="margin:4px 0 0;font-size:17px;line-height:1.55;color:${WS.black};font-style:italic;">${esc(v.quote)}</p>
              <p style="margin:14px 0 0;font-size:13px;font-weight:700;color:${WS.navy};">— ${esc(v.quote_author)}</p>
            </td></tr>
          </table>
        </td></tr>
        <tr><td class="ws-px" style="padding:28px 40px 0;">
          <p style="margin:0;font-family:Arial,Helvetica,sans-serif;font-size:16px;line-height:1.7;color:${WS.black};">${esc(v.story)}</p>
        </td></tr>
        <tr><td class="ws-px" align="left" style="padding:28px 40px 48px;">
          ${ctaButton({
        label: v.cta_label,
        url: v.cta_url
      })}
        </td></tr>
      `;
      return emailDoc({
        subject: interpolate(this.subject, v),
        preview: interpolate(this.preview, v),
        bodyHtml: body
      });
    }
  },
  // ── TEAM WELCOME — new WareSpace hire announcement (internal/broadcast) ─
  "team-welcome": {
    title: "Welcome to the team (new hire)",
    subject: "Welcome to WareSpace, {{hire_name}}",
    preview: "Meet our newest {{hire_role}}.",
    fromName: "WareSpace",
    fields: [{
      id: "hire_name",
      label: "New hire name",
      kind: "text"
    }, {
      id: "hire_role",
      label: "Role",
      kind: "text"
    }, {
      id: "hire_photo",
      label: "Headshot URL",
      kind: "url"
    }, {
      id: "hire_bio",
      label: "Short bio",
      kind: "textarea"
    }, {
      id: "fact_1",
      label: "Fun fact 1",
      kind: "text"
    }, {
      id: "fact_2",
      label: "Fun fact 2",
      kind: "text"
    }, {
      id: "fact_3",
      label: "Fun fact 3",
      kind: "text"
    }],
    defaults: {
      hire_name: "Austin Riel",
      hire_role: "Acquisitions Analyst",
      hire_photo: "assets/photos/photo-01.jpg",
      hire_bio: "Austin joins us from a regional brokerage where he closed 1.2M sq ft of flex-industrial last year. He'll be sourcing new buildings in our Texas and Southeast markets.",
      fact_1: "Makes a mean smoked brisket",
      fact_2: "Runs half-marathons on weekends",
      fact_3: "Secretly a very good pianist"
    },
    render(v) {
      const body = `
        ${headerRow()}
        <tr><td class="ws-px" align="center" style="padding:44px 40px 8px;">
          <h1 class="ws-h1" style="margin:0;font-family:Arial,Helvetica,sans-serif;font-weight:800;font-size:48px;line-height:1.05;color:${WS.navy};letter-spacing:-0.8px;">Welcome to the team!</h1>
        </td></tr>
        <tr><td class="ws-px" align="center" style="padding:24px 40px 0;">
          <img src="${esc(v.hire_photo)}" alt="${esc(v.hire_name)}" width="240" height="240" style="display:block;width:240px;height:240px;border-radius:14px;object-fit:cover;border:0;margin:0 auto;"/>
        </td></tr>
        <tr><td class="ws-px" align="center" style="padding:24px 40px 4px;">
          <div style="font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:32px;color:${WS.navy};line-height:1.1;">${esc(v.hire_name)}</div>
          <div style="display:inline-block;margin-top:14px;padding:10px 22px;background:${WS.green};color:${WS.white};border-radius:6px;font-family:Arial,Helvetica,sans-serif;font-weight:600;font-size:15px;">${esc(v.hire_role)}</div>
        </td></tr>
        <tr><td class="ws-px" style="padding:28px 40px 0;">
          <p style="margin:0;font-family:Arial,Helvetica,sans-serif;font-size:16px;line-height:1.7;color:${WS.black};text-align:center;">${esc(v.hire_bio)}</p>
        </td></tr>
        <tr><td class="ws-px" style="padding:28px 40px 44px;">
          <div style="font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:11px;letter-spacing:2px;text-transform:uppercase;color:${WS.gray400};text-align:center;margin-bottom:14px;">A few fun facts</div>
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
            <tr>
              ${[v.fact_1, v.fact_2, v.fact_3].filter(Boolean).map(f => `
                <td class="ws-stack" valign="top" style="padding:8px;width:33.33%;">
                  <div style="background:${WS.green40};border-radius:8px;padding:16px;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.45;color:${WS.navy};text-align:center;min-height:64px;">${esc(f)}</div>
                </td>
              `).join("")}
            </tr>
          </table>
        </td></tr>
      `;
      return emailDoc({
        subject: interpolate(this.subject, v),
        preview: interpolate(this.preview, v),
        bodyHtml: body
      });
    }
  },
  // ── MONTHLY NEWSLETTER — digest of buildings, tenants, growth ──────────
  "monthly-newsletter": {
    title: "Monthly newsletter",
    subject: "{{month}} at WareSpace — {{headline_teaser}}",
    preview: "New buildings, new tenants, and what's coming next.",
    fromName: "WareSpace",
    fields: [{
      id: "month",
      label: "Month",
      kind: "text"
    }, {
      id: "headline",
      label: "Hero headline",
      kind: "text"
    }, {
      id: "headline_teaser",
      label: "Subject teaser",
      kind: "text"
    }, {
      id: "lede",
      label: "Hero lede",
      kind: "textarea"
    }, {
      id: "story1_title",
      label: "Story 1 title",
      kind: "text"
    }, {
      id: "story1_body",
      label: "Story 1 body",
      kind: "textarea"
    }, {
      id: "story1_image",
      label: "Story 1 image URL",
      kind: "url"
    }, {
      id: "story2_title",
      label: "Story 2 title",
      kind: "text"
    }, {
      id: "story2_body",
      label: "Story 2 body",
      kind: "textarea"
    }, {
      id: "story2_image",
      label: "Story 2 image URL",
      kind: "url"
    }, {
      id: "stat_1_value",
      label: "Stat 1 value",
      kind: "text"
    }, {
      id: "stat_1_label",
      label: "Stat 1 label",
      kind: "text"
    }, {
      id: "stat_2_value",
      label: "Stat 2 value",
      kind: "text"
    }, {
      id: "stat_2_label",
      label: "Stat 2 label",
      kind: "text"
    }, {
      id: "stat_3_value",
      label: "Stat 3 value",
      kind: "text"
    }, {
      id: "stat_3_label",
      label: "Stat 3 label",
      kind: "text"
    }],
    defaults: {
      month: "April 2026",
      headline: "A big month for WareSpace.",
      headline_teaser: "two new buildings, fourteen new tenants",
      lede: "Spring came in hot. We closed on two new buildings, welcomed fourteen new tenants, and broke ground in Nashville. Here's what happened.",
      story1_title: "The Works on 5th is officially open",
      story1_body: "Our Austin building hit 72% leased in its first three weeks. Shout-out to Northside Brewing, Mobile Tire Rescue, and ten other teams already moved in.",
      story1_image: "assets/photos/photo-03.jpg",
      story2_title: "Nashville, we're coming",
      story2_body: "Construction kicks off next month on a 220,000 sq ft building in East Nashville. Sign up for early tour access below.",
      story2_image: "assets/photos/photo-02.jpg",
      stat_1_value: "+14",
      stat_1_label: "New tenants",
      stat_2_value: "+320K",
      stat_2_label: "Sq ft added",
      stat_3_value: "8",
      stat_3_label: "Active metros"
    },
    render(v) {
      const body = `
        ${headerRow()}
        <tr><td class="ws-px" style="padding:40px 40px 8px;">
          <div style="font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:12px;letter-spacing:2px;text-transform:uppercase;color:${WS.green};">${esc(v.month)}</div>
          <h1 class="ws-h1" style="margin:10px 0 14px;font-family:Arial,Helvetica,sans-serif;font-weight:800;font-size:40px;line-height:1.05;color:${WS.black};letter-spacing:-0.8px;">${esc(v.headline)}</h1>
          <p style="margin:0;font-family:Arial,Helvetica,sans-serif;font-size:16px;line-height:1.65;color:${WS.black};">${esc(v.lede)}</p>
        </td></tr>
        <!-- Stat strip -->
        <tr><td class="ws-px" style="padding:24px 40px 0;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="${WS.green40}" style="background:${WS.green40};border-radius:10px;">
            <tr>
              <td class="ws-stack" width="33%" valign="top" style="padding:22px 12px;text-align:center;font-family:Arial,Helvetica,sans-serif;">
                <div style="font-weight:800;font-size:30px;color:${WS.green};line-height:1;">${esc(v.stat_1_value)}</div>
                <div style="font-size:12px;letter-spacing:1px;text-transform:uppercase;color:${WS.navy};margin-top:6px;">${esc(v.stat_1_label)}</div>
              </td>
              <td class="ws-stack" width="33%" valign="top" style="padding:22px 12px;text-align:center;font-family:Arial,Helvetica,sans-serif;border-left:1px solid rgba(16,36,66,.1);border-right:1px solid rgba(16,36,66,.1);">
                <div style="font-weight:800;font-size:30px;color:${WS.green};line-height:1;">${esc(v.stat_2_value)}</div>
                <div style="font-size:12px;letter-spacing:1px;text-transform:uppercase;color:${WS.navy};margin-top:6px;">${esc(v.stat_2_label)}</div>
              </td>
              <td class="ws-stack" width="33%" valign="top" style="padding:22px 12px;text-align:center;font-family:Arial,Helvetica,sans-serif;">
                <div style="font-weight:800;font-size:30px;color:${WS.green};line-height:1;">${esc(v.stat_3_value)}</div>
                <div style="font-size:12px;letter-spacing:1px;text-transform:uppercase;color:${WS.navy};margin-top:6px;">${esc(v.stat_3_label)}</div>
              </td>
            </tr>
          </table>
        </td></tr>
        ${spacer(32)}
        <!-- Story 1 -->
        <tr><td class="ws-px" style="padding:0 40px;">
          <img src="${esc(v.story1_image)}" alt="${esc(v.story1_title)}" width="520" style="display:block;width:100%;max-width:520px;height:auto;border-radius:8px;border:0;"/>
        </td></tr>
        <tr><td class="ws-px" style="padding:16px 40px 0;">
          <h2 class="ws-h2" style="margin:0;font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:24px;line-height:1.15;color:${WS.black};">${esc(v.story1_title)}</h2>
          <p style="margin:8px 0 0;font-family:Arial,Helvetica,sans-serif;font-size:15.5px;line-height:1.6;color:${WS.black};">${esc(v.story1_body)}</p>
        </td></tr>
        ${spacer(32)}
        ${divider()}
        ${spacer(32)}
        <!-- Story 2 -->
        <tr><td class="ws-px" style="padding:0 40px;">
          <img src="${esc(v.story2_image)}" alt="${esc(v.story2_title)}" width="520" style="display:block;width:100%;max-width:520px;height:auto;border-radius:8px;border:0;"/>
        </td></tr>
        <tr><td class="ws-px" style="padding:16px 40px 48px;">
          <h2 class="ws-h2" style="margin:0;font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:24px;line-height:1.15;color:${WS.black};">${esc(v.story2_title)}</h2>
          <p style="margin:8px 0 0;font-family:Arial,Helvetica,sans-serif;font-size:15.5px;line-height:1.6;color:${WS.black};">${esc(v.story2_body)}</p>
        </td></tr>
      `;
      return emailDoc({
        subject: interpolate(this.subject, v),
        preview: interpolate(this.preview, v),
        bodyHtml: body
      });
    }
  },
  // ── WAITLIST ANNOUNCEMENT — "city launching" teaser ─────────────────────
  "waitlist": {
    title: "Waitlist — city launching",
    subject: "WareSpace is coming to {{city}}",
    preview: "Join the waitlist for early tours.",
    fromName: "WareSpace",
    fields: [{
      id: "city",
      label: "City",
      kind: "text"
    }, {
      id: "launch_window",
      label: "Launch window",
      kind: "text"
    }, {
      id: "sqft",
      label: "Planned sq ft",
      kind: "text"
    }, {
      id: "neighborhoods",
      label: "Neighborhoods",
      kind: "text"
    }, {
      id: "pitch",
      label: "Short pitch",
      kind: "textarea"
    }, {
      id: "cta_label",
      label: "CTA label",
      kind: "text"
    }, {
      id: "cta_url",
      label: "CTA URL",
      kind: "url"
    }],
    defaults: {
      city: "Nashville",
      launch_window: "Q3 2026",
      sqft: "220,000",
      neighborhoods: "East Nashville · Wedgewood-Houston",
      pitch: "Flex-industrial space, the way WareSpace does it. Clear heights, real loading, month-to-month tours. Get on the waitlist and we'll reach out before we open the doors to anyone else.",
      cta_label: "Join the waitlist",
      cta_url: "{{cta_url}}"
    },
    render(v) {
      const body = `
        ${headerRow({
        variant: "dark"
      })}
        <tr><td bgcolor="${WS.navy}" style="background:${WS.navy};padding:56px 40px 32px;" class="ws-px">
          <div style="font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:12px;letter-spacing:3px;text-transform:uppercase;color:${WS.bright};">Coming ${esc(v.launch_window)}</div>
          <h1 class="ws-h1" style="margin:14px 0 16px;font-family:Arial,Helvetica,sans-serif;font-weight:800;font-size:56px;line-height:1;color:${WS.white};letter-spacing:-1.5px;">Hello, ${esc(v.city)}.</h1>
          <p style="margin:0;font-family:Arial,Helvetica,sans-serif;font-size:17px;line-height:1.55;color:${WS.white};opacity:.85;">${esc(v.pitch)}</p>
        </td></tr>
        <tr><td bgcolor="${WS.navy}" class="ws-px" style="background:${WS.navy};padding:0 40px 40px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
            <tr>
              <td class="ws-stack" width="50%" valign="top" style="padding:20px 20px 0 0;font-family:Arial,Helvetica,sans-serif;border-top:1px solid rgba(255,255,255,.15);">
                <div style="font-weight:700;font-size:11px;letter-spacing:1.5px;text-transform:uppercase;color:${WS.white};opacity:.6;">Planned sq ft</div>
                <div style="font-weight:700;font-size:24px;color:${WS.white};margin-top:4px;">${esc(v.sqft)}</div>
              </td>
              <td class="ws-stack" width="50%" valign="top" style="padding:20px 0 0 20px;font-family:Arial,Helvetica,sans-serif;border-top:1px solid rgba(255,255,255,.15);">
                <div style="font-weight:700;font-size:11px;letter-spacing:1.5px;text-transform:uppercase;color:${WS.white};opacity:.6;">Neighborhoods</div>
                <div style="font-size:15px;color:${WS.white};margin-top:4px;line-height:1.45;">${esc(v.neighborhoods)}</div>
              </td>
            </tr>
          </table>
          <div style="margin-top:28px;">
            ${ctaButton({
        label: v.cta_label,
        url: v.cta_url,
        bg: WS.bright,
        fg: WS.navy
      })}
          </div>
        </td></tr>
      `;
      return emailDoc({
        subject: interpolate(this.subject, v),
        preview: interpolate(this.preview, v),
        bodyHtml: body
      });
    }
  },
  // ── TRANSACTIONAL — lease-docs-ready, short, utility ────────────────────
  "transactional-lease": {
    title: "Transactional — lease docs ready",
    subject: "Your lease for {{unit}} is ready to sign",
    preview: "Docs attached in the link below. Quick 5-minute review.",
    fromName: "WareSpace",
    fields: [{
      id: "first_name",
      label: "First name (merge)",
      kind: "text"
    }, {
      id: "unit",
      label: "Unit",
      kind: "text"
    }, {
      id: "property_name",
      label: "Property",
      kind: "text"
    }, {
      id: "start_date",
      label: "Lease start",
      kind: "date"
    }, {
      id: "term",
      label: "Term",
      kind: "text"
    }, {
      id: "rate",
      label: "Monthly rate",
      kind: "text"
    }, {
      id: "cta_url",
      label: "Sign link",
      kind: "url"
    }, {
      id: "rep_name",
      label: "Rep name",
      kind: "text"
    }, {
      id: "rep_email",
      label: "Rep email",
      kind: "text"
    }],
    defaults: {
      first_name: "{{contact.firstname}}",
      unit: "Unit 204",
      property_name: "The Works on 5th",
      start_date: "2026-06-01",
      term: "12 months",
      rate: "$6,720 / month",
      cta_url: "{{cta_url}}",
      rep_name: "Jordan Park",
      rep_email: "jordan@warespace.com"
    },
    render(v) {
      const body = `
        ${headerRow()}
        <tr><td class="ws-px" style="padding:40px 40px 8px;">
          <h1 class="ws-h1" style="margin:0;font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:28px;line-height:1.2;color:${WS.black};letter-spacing:-0.3px;">Your lease is ready, ${esc(v.first_name)}.</h1>
          <p style="margin:14px 0 0;font-family:Arial,Helvetica,sans-serif;font-size:15.5px;line-height:1.65;color:${WS.black};">Everything we talked about, on paper. Review takes about 5 minutes — any questions, reply to this email.</p>
        </td></tr>
        <tr><td class="ws-px" style="padding:24px 40px 0;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="border:1px solid ${WS.gray160};border-radius:10px;">
            <tr><td style="padding:18px 22px;font-family:Arial,Helvetica,sans-serif;border-bottom:1px solid ${WS.gray160};">
              <div style="font-size:11px;letter-spacing:1.5px;text-transform:uppercase;font-weight:700;color:${WS.gray400};">Property &amp; unit</div>
              <div style="font-size:16px;color:${WS.black};margin-top:3px;"><b>${esc(v.unit)}</b> · ${esc(v.property_name)}</div>
            </td></tr>
            <tr><td style="padding:18px 22px;font-family:Arial,Helvetica,sans-serif;border-bottom:1px solid ${WS.gray160};">
              <div style="font-size:11px;letter-spacing:1.5px;text-transform:uppercase;font-weight:700;color:${WS.gray400};">Start date</div>
              <div style="font-size:16px;color:${WS.black};margin-top:3px;">${esc(fmtDate(v.start_date))}</div>
            </td></tr>
            <tr><td style="padding:18px 22px;font-family:Arial,Helvetica,sans-serif;border-bottom:1px solid ${WS.gray160};">
              <div style="font-size:11px;letter-spacing:1.5px;text-transform:uppercase;font-weight:700;color:${WS.gray400};">Term</div>
              <div style="font-size:16px;color:${WS.black};margin-top:3px;">${esc(v.term)}</div>
            </td></tr>
            <tr><td style="padding:18px 22px;font-family:Arial,Helvetica,sans-serif;">
              <div style="font-size:11px;letter-spacing:1.5px;text-transform:uppercase;font-weight:700;color:${WS.gray400};">Rate</div>
              <div style="font-size:16px;color:${WS.black};margin-top:3px;">${esc(v.rate)}</div>
            </td></tr>
          </table>
        </td></tr>
        <tr><td class="ws-px" align="left" style="padding:28px 40px 8px;">
          ${ctaButton({
        label: "Review &amp; sign",
        url: v.cta_url
      })}
        </td></tr>
        <tr><td class="ws-px" align="left" style="padding:4px 40px 40px;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.6;color:${WS.gray400};">
          — ${esc(v.rep_name)} &nbsp;·&nbsp; <a href="mailto:${esc(v.rep_email)}" style="color:${WS.green};">${esc(v.rep_email)}</a>
        </td></tr>
      `;
      return emailDoc({
        subject: interpolate(this.subject, v),
        preview: interpolate(this.preview, v),
        bodyHtml: body
      });
    }
  }
};
function interpolate(tpl, v) {
  return String(tpl).replace(/\{\{\s*(\w+)\s*\}\}/g, (m, k) => {
    return v[k] != null && v[k] !== "" ? v[k] : m;
  });
}

/* -------------------------------------------------------------------------
   APP STATE + UI
   ------------------------------------------------------------------------- */

const state = {
  templateId: "welcome-prospect",
  values: {},
  previewMode: "desktop"
};
function currentTemplate() {
  return TEMPLATES[state.templateId];
}
function loadTemplate(id) {
  state.templateId = id;
  const t = TEMPLATES[id];
  state.values = {
    ...t.defaults
  };
  document.getElementById("tpl-title").textContent = t.title;
  document.querySelectorAll(".tpl-card").forEach(c => {
    c.setAttribute("aria-selected", c.dataset.template === id ? "true" : "false");
  });
  renderFields();
  renderPreview();
}
function renderFields() {
  const t = currentTemplate();
  const root = document.getElementById("form-fields");
  root.innerHTML = "";
  root.insertAdjacentHTML("beforeend", `<div class="form-section-title">Inbox</div>`);
  root.insertAdjacentHTML("beforeend", fieldInput({
    id: "__subject",
    label: "Subject line",
    kind: "text",
    value: state.values.__subject ?? t.subject
  }));
  root.insertAdjacentHTML("beforeend", fieldInput({
    id: "__fromName",
    label: "From name",
    kind: "text",
    value: state.values.__fromName ?? t.fromName
  }));
  root.insertAdjacentHTML("beforeend", `<div class="form-section-title">Content</div>`);
  for (const f of t.fields) {
    root.insertAdjacentHTML("beforeend", fieldInput({
      ...f,
      value: state.values[f.id] ?? ""
    }));
  }
  root.querySelectorAll("[data-field]").forEach(el => {
    const key = el.dataset.field;
    el.addEventListener("input", e => {
      state.values[key] = e.target.value;
      renderPreview();
    });
    el.addEventListener("change", e => {
      state.values[key] = e.target.value;
      renderPreview();
    });
  });
  root.querySelectorAll("[data-accent-picker]").forEach(picker => {
    const key = picker.dataset.accentPicker;
    picker.querySelectorAll("button").forEach(btn => {
      btn.addEventListener("click", () => {
        state.values[key] = btn.dataset.accent;
        picker.querySelectorAll("button").forEach(b => b.setAttribute("aria-selected", b.dataset.accent === btn.dataset.accent ? "true" : "false"));
        renderPreview();
      });
    });
  });
}
function fieldInput({
  id,
  label,
  kind,
  placeholder,
  value
}) {
  const v = esc(value ?? "");
  if (kind === "textarea") {
    return `<div class="field"><label for="f-${id}">${esc(label)}</label><textarea id="f-${id}" data-field="${id}" rows="3" placeholder="${esc(placeholder || "")}">${v}</textarea></div>`;
  }
  if (kind === "date") {
    return `<div class="field"><label for="f-${id}">${esc(label)}</label><input id="f-${id}" data-field="${id}" type="date" value="${v}"/></div>`;
  }
  if (kind === "url") {
    return `<div class="field"><label for="f-${id}">${esc(label)}</label><input id="f-${id}" data-field="${id}" type="url" placeholder="${esc(placeholder || "")}" value="${v}"/><div class="field__hint">Leave as <span class="var-chip">{{cta_url}}</span> to use a HubSpot merge tag.</div></div>`;
  }
  if (kind === "accent") {
    const selected = value || "green";
    return `<div class="field"><label>${esc(label)}</label><div class="field__accent-picker" data-accent-picker="${id}">${ACCENTS.map(a => `<button type="button" data-accent="${a.key}" title="${a.label}" style="background:${a.hex};" aria-selected="${a.key === selected ? "true" : "false"}"></button>`).join("")}</div></div>`;
  }
  return `<div class="field"><label for="f-${id}">${esc(label)}</label><input id="f-${id}" data-field="${id}" type="text" placeholder="${esc(placeholder || "")}" value="${v}"/></div>`;
}
function renderPreview() {
  const t = currentTemplate();
  const v = {
    ...t.defaults,
    ...state.values
  };
  const subject = state.values.__subject !== undefined && state.values.__subject !== "" ? interpolate(state.values.__subject, v) : interpolate(t.subject, v);
  const fromName = state.values.__fromName || t.fromName;
  const preview = v.preheader || interpolate(t.preview, v);
  document.getElementById("email-meta").innerHTML = `
    <dt>From</dt><dd>${esc(fromName)} &lt;hello@warespace.com&gt;</dd>
    <dt>Subject</dt><dd class="subject">${esc(subject)}</dd>
    <dt>Preview</dt><dd style="color:var(--gray-400);">${esc(preview)}</dd>
  `;
  const html = t.render(v);
  const frame = document.getElementById("email-frame");
  frame.innerHTML = `<iframe srcdoc="${esc(html)}" style="width:100%;border:0;background:#fff;display:block;" id="preview-iframe"></iframe>`;
  const iframe = frame.querySelector("iframe");
  iframe.addEventListener("load", () => {
    try {
      iframe.style.height = iframe.contentDocument.documentElement.scrollHeight + 20 + "px";
    } catch (e) {
      iframe.style.height = "1200px";
    }
  });
  state._lastHtml = html;
  state._lastSubject = subject;
}

/* -------------------------------------------------------------------------
   EXPORT
   ------------------------------------------------------------------------- */

function openCodeModal() {
  document.getElementById("code-pre").textContent = state._lastHtml || "";
  document.getElementById("code-modal").setAttribute("data-open", "true");
}
function closeCodeModal() {
  document.getElementById("code-modal").setAttribute("data-open", "false");
}
function copyToClipboard(text, msg = "Copied") {
  navigator.clipboard.writeText(text).then(() => toast(msg)).catch(() => toast("Copy failed"));
}
function downloadHtml() {
  const blob = new Blob([state._lastHtml || ""], {
    type: "text/html;charset=utf-8"
  });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  const slug = (state.templateId || "email").replace(/[^\w-]+/g, "-");
  a.download = `warespace-${slug}.html`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  toast("Downloaded " + a.download);
}
function toast(msg) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.setAttribute("data-show", "true");
  clearTimeout(toast._id);
  toast._id = setTimeout(() => t.setAttribute("data-show", "false"), 1800);
}
document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("logo-slot").innerHTML = window.WareSpaceLogo({
    height: 32
  });
  document.querySelectorAll(".tpl-card").forEach(c => {
    c.addEventListener("click", () => loadTemplate(c.dataset.template));
  });
  document.querySelectorAll(".preview-bar__mode button").forEach(b => {
    b.addEventListener("click", () => {
      state.previewMode = b.dataset.mode;
      document.querySelectorAll(".preview-bar__mode button").forEach(x => x.setAttribute("aria-selected", x === b ? "true" : "false"));
      document.getElementById("canvas").setAttribute("data-mode", b.dataset.mode);
    });
  });
  document.getElementById("btn-copy-subject").addEventListener("click", () => copyToClipboard(state._lastSubject || "", "Subject copied"));
  document.getElementById("btn-show-code").addEventListener("click", openCodeModal);
  document.getElementById("btn-download").addEventListener("click", downloadHtml);
  document.getElementById("btn-download-modal").addEventListener("click", downloadHtml);
  document.getElementById("btn-copy-code").addEventListener("click", () => copyToClipboard(state._lastHtml || "", "HTML copied"));
  document.querySelector(".code-modal__h__close").addEventListener("click", closeCodeModal);
  document.getElementById("code-modal").addEventListener("click", e => {
    if (e.target.id === "code-modal") closeCodeModal();
  });
  loadTemplate(state.templateId);
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "emails.js", error: String((e && e.message) || e) }); }

})();
